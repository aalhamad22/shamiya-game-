#!/usr/bin/env bash
# Netlify build script.
#
# Netlify's database stores its connection links under NETLIFY_DATABASE_URL /
# NETLIFY_DATABASE_URL_UNPOOLED. The Prisma CLI (generate / db push / seed)
# expects DATABASE_URL / DIRECT_URL, so we map them here. If you instead set your
# own DATABASE_URL, that takes priority.
set -e

export DATABASE_URL="${DATABASE_URL:-$NETLIFY_DATABASE_URL}"
export DIRECT_URL="${DIRECT_URL:-${NETLIFY_DATABASE_URL_UNPOOLED:-$DATABASE_URL}}"

# Always (re)generate the Prisma client for the build.
npx prisma generate

if [ -n "$DATABASE_URL" ]; then
  echo "→ Database URL found. Creating tables (db push) and loading fixtures (seed)…"
  # Create/update the tables to match the schema. Idempotent.
  npx prisma db push --skip-generate
  # Load the Round of 32 + settings. The seed skips rows that already exist, so
  # it is safe to run on every deploy.
  npx tsx prisma/seed.ts || echo "  (seed step reported a problem — continuing build)"
else
  echo "→ No database URL set. Building anyway; the site will show the"
  echo "  'database not connected' notice until a database is added."
fi

# Build the Next.js app.
npx next build
