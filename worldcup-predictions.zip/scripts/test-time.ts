import { kuwaitLocalStringToUtc, utcToKuwaitLocalString, isLocked } from "../src/lib/time";
let pass=0, fail=0;
function eq(label:string, got:string, want:string){ if(got===want){pass++;console.log(`  ✓ ${label} => ${got}`);}else{fail++;console.log(`  ✗ ${label} => got ${got}, want ${want}`);} }

// Kuwait 20:00 == 17:00 UTC (UTC+3)
eq("Kuwait 20:00 -> UTC", kuwaitLocalStringToUtc("2026-06-28T20:00").toISOString(), "2026-06-28T17:00:00.000Z");
eq("Kuwait 00:30 -> UTC (prev day)", kuwaitLocalStringToUtc("2026-07-01T00:30").toISOString(), "2026-06-30T21:30:00.000Z");
// round-trip
eq("UTC -> Kuwait local string", utcToKuwaitLocalString(new Date("2026-06-28T17:00:00.000Z")), "2026-06-28T20:00");
eq("round-trip", utcToKuwaitLocalString(kuwaitLocalStringToUtc("2026-07-05T23:00")), "2026-07-05T23:00");

// lock logic
const k = kuwaitLocalStringToUtc("2026-06-28T20:00");
console.log("  ✓ isLocked before kickoff =", isLocked(k, new Date("2026-06-28T16:59:00Z")), "(want false)");
console.log("  ✓ isLocked at/after kickoff =", isLocked(k, new Date("2026-06-28T17:00:00Z")), "(want true)");
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
