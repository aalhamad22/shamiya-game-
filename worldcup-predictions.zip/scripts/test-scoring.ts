import { scoreMatch } from "../src/lib/scoring";

let pass = 0, fail = 0;
function check(label: string, got: number, want: number) {
  if (got === want) { pass++; console.log(`  ✓ ${label} => ${got}`); }
  else { fail++; console.log(`  ✗ ${label} => got ${got}, want ${want}`); }
}
const KO = { status: "FINISHED", isKnockout: true } as const;
const A = "TEAM_A" as const, B = "TEAM_B" as const;
const N = "NINETY" as const, P = "PENALTIES" as const;
const reqTrue = { methodRequiresCorrectWinner: true };
const reqFalse = { methodRequiresCorrectWinner: false };

console.log("Knockout, methodRequiresCorrectWinner = TRUE (default):");
check("winner+method right", scoreMatch({predictedWinner:A,predictedMethod:N},{...KO,resultWinner:A,resultMethod:N},reqTrue),3);
check("winner right, method wrong", scoreMatch({predictedWinner:A,predictedMethod:P},{...KO,resultWinner:A,resultMethod:N},reqTrue),2);
check("winner wrong, method right", scoreMatch({predictedWinner:B,predictedMethod:N},{...KO,resultWinner:A,resultMethod:N},reqTrue),0);
check("winner wrong, method wrong", scoreMatch({predictedWinner:B,predictedMethod:P},{...KO,resultWinner:A,resultMethod:N},reqTrue),0);

console.log("Knockout, methodRequiresCorrectWinner = FALSE:");
check("winner+method right", scoreMatch({predictedWinner:A,predictedMethod:N},{...KO,resultWinner:A,resultMethod:N},reqFalse),3);
check("winner right, method wrong", scoreMatch({predictedWinner:A,predictedMethod:P},{...KO,resultWinner:A,resultMethod:N},reqFalse),2);
check("winner wrong, method right", scoreMatch({predictedWinner:B,predictedMethod:N},{...KO,resultWinner:A,resultMethod:N},reqFalse),1);
check("winner wrong, method wrong", scoreMatch({predictedWinner:B,predictedMethod:P},{...KO,resultWinner:A,resultMethod:N},reqFalse),0);

console.log("Group game (isKnockout=false), method ignored:");
const GR = { status: "FINISHED", isKnockout: false } as const;
check("correct win", scoreMatch({predictedWinner:A,predictedMethod:null},{...GR,resultWinner:A,resultMethod:null},reqTrue),2);
check("correct draw", scoreMatch({predictedWinner:"DRAW",predictedMethod:null},{...GR,resultWinner:"DRAW",resultMethod:null},reqTrue),2);
check("wrong result", scoreMatch({predictedWinner:B,predictedMethod:null},{...GR,resultWinner:A,resultMethod:null},reqTrue),0);

console.log("Not finished:");
check("scheduled match", scoreMatch({predictedWinner:A,predictedMethod:N},{status:"SCHEDULED",isKnockout:true,resultWinner:null,resultMethod:null},reqTrue),0);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
