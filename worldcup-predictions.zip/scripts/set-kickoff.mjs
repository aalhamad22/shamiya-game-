import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
// Kuwait is UTC+3, so 22:00 Kuwait == 19:00 UTC.
const kickoffUtc = new Date(Date.UTC(2026, 5, 28, 22, 0) - 3 * 3600 * 1000);
const r = await prisma.match.updateMany({
  where: { teamA: "South Africa", teamB: "Canada" },
  data: { kickoffUtc },
});
console.log("Updated", r.count, "match(es). New kickoff (UTC):", kickoffUtc.toISOString());
await prisma.$disconnect();
