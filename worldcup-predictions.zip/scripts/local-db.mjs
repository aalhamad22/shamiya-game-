// Starts a real, self-contained PostgreSQL on 127.0.0.1:5433 for LOCAL preview
// only. No system install, no cloud account. Data lives in ./.localdb.
// Keep this process running while you use the app locally.
import EmbeddedPostgres from "embedded-postgres";
import { existsSync } from "node:fs";

const DATA_DIR = new URL("../.localdb", import.meta.url).pathname;

const pg = new EmbeddedPostgres({
  databaseDir: DATA_DIR,
  user: "wcuser",
  password: "wcpass",
  port: 5433,
  persistent: true,
});

const firstRun = !existsSync(DATA_DIR);
if (firstRun) {
  console.log("Initialising database files (first run)…");
  await pg.initialise();
}
await pg.start();
console.log("Postgres started on 127.0.0.1:5433");

try {
  await pg.createDatabase("worldcup");
  console.log("Created database 'worldcup'");
} catch {
  console.log("Database 'worldcup' already exists — ok");
}

console.log("READY");

// Stay alive so Postgres keeps running.
process.stdin.resume();
const stop = async () => {
  try {
    await pg.stop();
  } finally {
    process.exit(0);
  }
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
