import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

// Kuwait is UTC+3. Convert a Kuwait wall-clock "YYYY-MM-DDTHH:mm" to UTC.
const toUtc = (s) => {
  const [, y, mo, d, h, mi] = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);
  return new Date(Date.UTC(+y, +mo - 1, +d, +h, +mi) - 3 * 3600 * 1000);
};

// [matchTeamA, matchTeamB(current), KuwaitKickoff, newTeamB?]
// Times are real FIFA ET slots + 7h = Kuwait time.
const SCHEDULE = [
  ["South Africa", "Canada", "2026-06-28T22:00"],
  ["Brazil", "Japan", "2026-06-29T20:00"],
  ["Germany", "Paraguay", "2026-06-29T23:30"],
  ["Netherlands", "Morocco", "2026-06-30T04:00"],
  ["Ivory Coast", "Norway", "2026-06-30T20:00"],
  ["France", "Sweden", "2026-07-01T00:00"],
  ["Mexico", "Ecuador", "2026-07-01T04:00"],
  ["England", "DR Congo", "2026-07-01T19:00"],
  ["Belgium", "Senegal", "2026-07-01T23:00"],
  ["United States", "Bosnia and Herzegovina", "2026-07-02T03:00"],
  ["Spain", "Austria", "2026-07-02T22:00"],
  ["Portugal", "Croatia", "2026-07-03T02:00"],
  ["Switzerland", "Algeria", "2026-07-03T06:00"],
  ["Australia", "Egypt", "2026-07-03T21:00"],
  ["Argentina", "Cabo Verde", "2026-07-04T01:00"],
  ["Colombia", "TBD", "2026-07-04T04:30", "Ghana"],
];

for (const [a, b, kuwait, newB] of SCHEDULE) {
  const r = await prisma.match.updateMany({
    where: { teamA: a, teamB: b },
    data: { kickoffUtc: toUtc(kuwait), ...(newB ? { teamB: newB } : {}) },
  });
  console.log(`${a} vs ${newB ?? b}: ${kuwait} Kuwait  (updated ${r.count})`);
}

// Champion deadline = first kickoff (South Africa vs Canada).
await prisma.settings.update({
  where: { id: 1 },
  data: { championDeadlineUtc: toUtc("2026-06-28T22:00") },
});
console.log("Champion deadline set to first kickoff.");
await prisma.$disconnect();
