// Seed script: creates the Settings row and the Round of 32 fixtures.
//
// Run with:  npm run seed
//
// IMPORTANT — KICKOFF TIMES ARE PLACEHOLDERS.
// The matchups below are the confirmed Round of 32 pairings, but the kickoff
// dates/times are best-guess placeholders. Verify each one against the official
// FIFA schedule and fix any that are wrong in the Admin panel (Fixtures tab).
// All times here are written in KUWAIT local time and converted to UTC on save.

import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

// Kuwait is UTC+3 year-round (no daylight saving). Convert a Kuwait wall-clock
// string "YYYY-MM-DDTHH:mm" to a real UTC Date by subtracting 3 hours.
const KUWAIT_OFFSET_HOURS = 3;
function kuwaitLocalToUtc(local: string): Date {
  const m = local.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);
  if (!m) throw new Error(`Bad time: ${local}`);
  const [, y, mo, d, h, mi] = m;
  return new Date(Date.UTC(+y, +mo - 1, +d, +h, +mi) - KUWAIT_OFFSET_HOURS * 3600 * 1000);
}

// [teamA, teamB, kuwaitKickoff]
// Real FIFA Round of 32 schedule. Times are the official Eastern Time (ET)
// kickoffs converted to Kuwait time (Kuwait = ET + 7 hours).
// Source: https://fwclive.us/schedule/round-of-32/
const ROUND_OF_32: Array<[string, string, string]> = [
  ["South Africa", "Canada", "2026-06-28T22:00"], // Jun 28, 3pm ET
  ["Brazil", "Japan", "2026-06-29T20:00"], // Jun 29, 1pm ET
  ["Germany", "Paraguay", "2026-06-29T23:30"], // Jun 29, 4:30pm ET
  ["Netherlands", "Morocco", "2026-06-30T04:00"], // Jun 29, 9pm ET
  ["Ivory Coast", "Norway", "2026-06-30T20:00"], // Jun 30, 1pm ET
  ["France", "Sweden", "2026-07-01T00:00"], // Jun 30, 5pm ET
  ["Mexico", "Ecuador", "2026-07-01T04:00"], // Jun 30, 9pm ET
  ["England", "DR Congo", "2026-07-01T19:00"], // Jul 1, 12pm ET
  ["Belgium", "Senegal", "2026-07-01T23:00"], // Jul 1, 4pm ET
  ["United States", "Bosnia and Herzegovina", "2026-07-02T03:00"], // Jul 1, 8pm ET
  ["Spain", "Austria", "2026-07-02T22:00"], // Jul 2, 3pm ET
  ["Portugal", "Croatia", "2026-07-03T02:00"], // Jul 2, 7pm ET
  ["Switzerland", "Algeria", "2026-07-03T06:00"], // Jul 2, 11pm ET
  ["Australia", "Egypt", "2026-07-03T21:00"], // Jul 3, 2pm ET
  ["Argentina", "Cabo Verde", "2026-07-04T01:00"], // Jul 3, 6pm ET
  ["Colombia", "Ghana", "2026-07-04T04:30"], // Jul 3, 9:30pm ET
];

// Later rounds. The TEAMS are unknown until the bracket is decided, so these are
// placeholders ("TBD vs TBD") with the official DATES. The kickoff TIMES are
// placeholders too (except the Final) — set the real teams and times in the
// Admin panel as each round is confirmed.
// [round, kuwaitKickoff]
const LATER_ROUNDS: Array<[string, string]> = [
  // Round of 16 — July 4–7 (2 matches per day)
  ["ROUND_OF_16", "2026-07-04T21:00"],
  ["ROUND_OF_16", "2026-07-04T23:30"],
  ["ROUND_OF_16", "2026-07-05T21:00"],
  ["ROUND_OF_16", "2026-07-05T23:30"],
  ["ROUND_OF_16", "2026-07-06T21:00"],
  ["ROUND_OF_16", "2026-07-06T23:30"],
  ["ROUND_OF_16", "2026-07-07T21:00"],
  ["ROUND_OF_16", "2026-07-07T23:30"],
  // Quarter-finals — July 9–11
  ["QUARTER_FINAL", "2026-07-09T22:00"],
  ["QUARTER_FINAL", "2026-07-10T22:00"],
  ["QUARTER_FINAL", "2026-07-11T21:00"],
  ["QUARTER_FINAL", "2026-07-11T23:30"],
  // Semi-finals — July 14–15
  ["SEMI_FINAL", "2026-07-14T22:00"],
  ["SEMI_FINAL", "2026-07-15T22:00"],
  // Third-place play-off — July 18
  ["THIRD_PLACE", "2026-07-18T22:00"],
  // Final — July 19, 7pm ET = July 20, 02:00 Kuwait
  ["FINAL", "2026-07-20T02:00"],
];

async function main() {
  // ---- Settings (single row, id = 1) ----
  // Champion picks lock at the kickoff of the FIRST Round of 32 match.
  const firstKickoff = kuwaitLocalToUtc(ROUND_OF_32[0][2]);

  await prisma.settings.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      tournamentName: "World Cup 2026",
      methodRequiresCorrectWinner: true,
      championBonusPoints: 5,
      championEnabled: true,
      championDeadlineUtc: firstKickoff,
    },
  });
  console.log("✓ Settings row ready");

  // ---- Round of 32 fixtures ----
  // Skip ones that already exist (so re-running seed is safe).
  let created = 0;
  for (let i = 0; i < ROUND_OF_32.length; i++) {
    const [teamA, teamB, kuwait] = ROUND_OF_32[i];
    const kickoffUtc = kuwaitLocalToUtc(kuwait);

    const exists = await prisma.match.findFirst({
      where: { round: "ROUND_OF_32", teamA, teamB },
    });
    if (exists) continue;

    await prisma.match.create({
      data: {
        round: "ROUND_OF_32",
        teamA,
        teamB,
        kickoffUtc,
        isKnockout: true,
        order: i,
      },
    });
    created++;
  }
  console.log(`✓ Round of 32: created ${created} new match(es)`);

  // ---- Later-round placeholders (Round of 16 → Final) ----
  // Identified by round + kickoff time (since teams are all "TBD"), so re-running
  // the seed won't create duplicates.
  let laterCreated = 0;
  for (let i = 0; i < LATER_ROUNDS.length; i++) {
    const [round, kuwait] = LATER_ROUNDS[i];
    const kickoffUtc = kuwaitLocalToUtc(kuwait);

    const exists = await prisma.match.findFirst({ where: { round: round as never, kickoffUtc } });
    if (exists) continue;

    await prisma.match.create({
      data: {
        round: round as never,
        teamA: "TBD",
        teamB: "TBD",
        kickoffUtc,
        isKnockout: true,
        order: 100 + i,
      },
    });
    laterCreated++;
  }
  console.log(`✓ Later rounds: created ${laterCreated} placeholder match(es)`);
  console.log("\nDone. Set real teams/times for later rounds in the Admin panel.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
