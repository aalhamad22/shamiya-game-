/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    // Server Actions (saving predictions, name+PIN login, admin changes) are
    // POST requests that Next.js guards with an origin check. Behind Netlify's
    // proxy the forwarded host can differ from the origin, which makes Next
    // reject the action — the symptom is "saving does nothing" even though the
    // pages load fine. Allowing the deploy domains here fixes that.
    //
    // If you put the site on a CUSTOM DOMAIN later, add it to this list (or set
    // the SERVER_ACTION_ORIGIN env var to your domain, e.g. "myapp.com").
    serverActions: {
      allowedOrigins: [
        "*.netlify.app",
        "*.netlify.com",
        ...(process.env.SERVER_ACTION_ORIGIN ? [process.env.SERVER_ACTION_ORIGIN] : []),
      ],
    },
  },
};

export default nextConfig;
