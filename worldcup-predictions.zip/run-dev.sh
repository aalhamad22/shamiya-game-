#!/bin/zsh
export PATH="/Users/abdulaziz/node-runtime/node-v22.12.0-darwin-arm64/bin:$PATH"
cd /Users/abdulaziz/worldcup-predictions
exec node node_modules/next/dist/bin/next dev -p 3100
