"use server";

// Admin server actions. EVERY mutating action re-checks isAdmin() so the admin
// area can't be driven by a non-admin even if they discover the action names.

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import {
  isAdmin,
  checkAdminPassword,
  setAdminCookie,
  clearAdminCookie,
} from "@/lib/auth";
import { kuwaitLocalStringToUtc } from "@/lib/time";
import type { Round, Winner, Method } from "@prisma/client";

type Result = { ok: boolean; error?: string };

const ROUNDS = [
  "ROUND_OF_32",
  "ROUND_OF_16",
  "QUARTER_FINAL",
  "SEMI_FINAL",
  "THIRD_PLACE",
  "FINAL",
];
const WINNERS = ["TEAM_A", "TEAM_B", "DRAW"];
const METHODS = ["NINETY", "EXTRA_TIME", "PENALTIES"];

function guard(): Result | null {
  return isAdmin() ? null : { ok: false, error: "Not authorised." };
}

function refresh() {
  revalidatePath("/admin");
  revalidatePath("/");
  revalidatePath("/my");
  revalidatePath("/play");
}

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

export async function adminLogin(password: string): Promise<Result> {
  if (!checkAdminPassword(password)) return { ok: false, error: "Wrong password." };
  setAdminCookie();
  return { ok: true };
}

export async function adminLogout(): Promise<Result> {
  clearAdminCookie();
  return { ok: true };
}

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

type MatchInput = {
  round: string;
  teamA: string;
  teamB: string;
  kickoffLocal: string; // "YYYY-MM-DDTHH:mm" in Kuwait time
  isKnockout: boolean;
};

function validateMatch(input: MatchInput): string | null {
  if (!ROUNDS.includes(input.round)) return "Invalid round.";
  if (!input.teamA.trim() || !input.teamB.trim()) return "Both teams are required.";
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(input.kickoffLocal))
    return "Invalid kickoff time.";
  return null;
}

export async function createMatch(input: MatchInput): Promise<Result> {
  const g = guard();
  if (g) return g;
  const err = validateMatch(input);
  if (err) return { ok: false, error: err };

  await prisma.match.create({
    data: {
      round: input.round as Round,
      teamA: input.teamA.trim(),
      teamB: input.teamB.trim(),
      kickoffUtc: kuwaitLocalStringToUtc(input.kickoffLocal),
      isKnockout: input.isKnockout,
    },
  });
  refresh();
  return { ok: true };
}

export async function updateMatch(id: string, input: MatchInput): Promise<Result> {
  const g = guard();
  if (g) return g;
  const err = validateMatch(input);
  if (err) return { ok: false, error: err };

  await prisma.match.update({
    where: { id },
    data: {
      round: input.round as Round,
      teamA: input.teamA.trim(),
      teamB: input.teamB.trim(),
      kickoffUtc: kuwaitLocalStringToUtc(input.kickoffLocal),
      isKnockout: input.isKnockout,
    },
  });
  refresh();
  return { ok: true };
}

export async function deleteMatch(id: string): Promise<Result> {
  const g = guard();
  if (g) return g;
  // Predictions for this match are removed via the onDelete: Cascade relation.
  await prisma.match.delete({ where: { id } });
  refresh();
  return { ok: true };
}

/**
 * Enter (or clear) a match result. Saving recalculates everyone's score because
 * the leaderboard is always derived live from results — nothing to recompute by
 * hand. Passing winner = "" clears the result back to scheduled.
 */
export async function setResult(
  matchId: string,
  winner: string,
  method: string | null
): Promise<Result> {
  const g = guard();
  if (g) return g;

  const match = await prisma.match.findUnique({ where: { id: matchId } });
  if (!match) return { ok: false, error: "Match not found." };

  // Clear the result.
  if (!winner) {
    await prisma.match.update({
      where: { id: matchId },
      data: { status: "SCHEDULED", resultWinner: null, resultMethod: null },
    });
    refresh();
    return { ok: true };
  }

  if (!WINNERS.includes(winner)) return { ok: false, error: "Invalid winner." };
  if (winner === "DRAW" && match.isKnockout)
    return { ok: false, error: "A knockout match cannot be a draw." };

  let resultMethod: Method | null = null;
  if (match.isKnockout && winner !== "DRAW") {
    if (!method || !METHODS.includes(method))
      return { ok: false, error: "Choose how the match was decided." };
    resultMethod = method as Method;
  }

  await prisma.match.update({
    where: { id: matchId },
    data: {
      status: "FINISHED",
      resultWinner: winner as Winner,
      resultMethod,
    },
  });
  refresh();
  return { ok: true };
}

// ---------------------------------------------------------------------------
// Manual point adjustments (the "fix a mistake" feature)
// ---------------------------------------------------------------------------

export async function addAdjustment(
  playerId: string,
  points: number,
  reason: string
): Promise<Result> {
  const g = guard();
  if (g) return g;
  if (!Number.isInteger(points) || points === 0)
    return { ok: false, error: "Points must be a non-zero whole number." };
  if (!reason.trim()) return { ok: false, error: "Add a short reason." };

  const player = await prisma.player.findUnique({ where: { id: playerId } });
  if (!player) return { ok: false, error: "Player not found." };

  await prisma.adjustment.create({
    data: { playerId, points, reason: reason.trim() },
  });
  refresh();
  return { ok: true };
}

export async function deleteAdjustment(id: string): Promise<Result> {
  const g = guard();
  if (g) return g;
  await prisma.adjustment.delete({ where: { id } });
  refresh();
  return { ok: true };
}

// ---------------------------------------------------------------------------
// Settings & champion result
// ---------------------------------------------------------------------------

type SettingsInput = {
  tournamentName: string;
  methodRequiresCorrectWinner: boolean;
  championEnabled: boolean;
  championBonusPoints: number;
  championDeadlineLocal: string | null; // Kuwait local, or null/"" to clear
};

export async function updateSettings(input: SettingsInput): Promise<Result> {
  const g = guard();
  if (g) return g;
  if (!Number.isInteger(input.championBonusPoints) || input.championBonusPoints < 0)
    return { ok: false, error: "Champion bonus must be a non-negative whole number." };

  let deadline: Date | null = null;
  if (input.championDeadlineLocal && input.championDeadlineLocal.trim()) {
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(input.championDeadlineLocal))
      return { ok: false, error: "Invalid champion deadline." };
    deadline = kuwaitLocalStringToUtc(input.championDeadlineLocal);
  }

  await prisma.settings.upsert({
    where: { id: 1 },
    update: {
      tournamentName: input.tournamentName.trim() || "World Cup 2026",
      methodRequiresCorrectWinner: input.methodRequiresCorrectWinner,
      championEnabled: input.championEnabled,
      championBonusPoints: input.championBonusPoints,
      championDeadlineUtc: deadline,
    },
    create: {
      id: 1,
      tournamentName: input.tournamentName.trim() || "World Cup 2026",
      methodRequiresCorrectWinner: input.methodRequiresCorrectWinner,
      championEnabled: input.championEnabled,
      championBonusPoints: input.championBonusPoints,
      championDeadlineUtc: deadline,
    },
  });
  refresh();
  return { ok: true };
}

// ---------------------------------------------------------------------------
// Read helper: everyone's predictions for one match (admin "view predictions")
// ---------------------------------------------------------------------------

export async function getMatchPredictions(
  matchId: string
): Promise<{ ok: boolean; rows?: { name: string; winner: string; method: string | null }[]; error?: string }> {
  const g = guard();
  if (g) return g;
  const preds = await prisma.prediction.findMany({
    where: { matchId },
    include: { player: { select: { name: true } } },
    orderBy: { player: { name: "asc" } },
  });
  return {
    ok: true,
    rows: preds.map((p) => ({
      name: p.player.name,
      winner: p.predictedWinner,
      method: p.predictedMethod,
    })),
  };
}

/** Set or clear which team won the tournament (triggers champion bonus). */
export async function setChampionResult(team: string | null): Promise<Result> {
  const g = guard();
  if (g) return g;
  await prisma.settings.upsert({
    where: { id: 1 },
    update: { championResult: team && team.trim() ? team.trim() : null },
    create: { id: 1, championResult: team && team.trim() ? team.trim() : null },
  });
  refresh();
  return { ok: true };
}
