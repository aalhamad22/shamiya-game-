import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/settings";
import { isAdmin } from "@/lib/auth";
import { formatKuwait, utcToKuwaitLocalString } from "@/lib/time";
import AdminLogin from "@/components/admin/AdminLogin";
import AdminDashboard from "@/components/admin/AdminDashboard";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  if (!isAdmin()) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-extrabold">Admin</h1>
        <AdminLogin />
      </div>
    );
  }

  const [matches, players, adjustments, settings] = await Promise.all([
    prisma.match.findMany({ orderBy: [{ kickoffUtc: "asc" }, { order: "asc" }] }),
    prisma.player.findMany({ orderBy: { name: "asc" } }),
    prisma.adjustment.findMany({
      include: { player: { select: { name: true } } },
      orderBy: { createdAt: "desc" },
    }),
    getSettings(),
  ]);

  const teamSet = new Set<string>();
  for (const m of matches) {
    teamSet.add(m.teamA);
    teamSet.add(m.teamB);
  }
  teamSet.delete("TBD");
  const teams = [...teamSet].sort((a, b) => a.localeCompare(b));

  return (
    <AdminDashboard
      matches={matches.map((m) => ({
        id: m.id,
        round: m.round,
        teamA: m.teamA,
        teamB: m.teamB,
        kickoffLocal: utcToKuwaitLocalString(m.kickoffUtc),
        kickoffLabel: formatKuwait(m.kickoffUtc),
        isKnockout: m.isKnockout,
        status: m.status,
        resultWinner: m.resultWinner,
        resultMethod: m.resultMethod,
      }))}
      players={players.map((p) => ({
        id: p.id,
        name: p.name,
        championPick: p.championPick,
      }))}
      adjustments={adjustments.map((a) => ({
        id: a.id,
        playerName: a.player.name,
        points: a.points,
        reason: a.reason,
        createdLabel: formatKuwait(a.createdAt),
      }))}
      teams={teams}
      settings={{
        tournamentName: settings.tournamentName,
        methodRequiresCorrectWinner: settings.methodRequiresCorrectWinner,
        championEnabled: settings.championEnabled,
        championBonusPoints: settings.championBonusPoints,
        championDeadlineLocal: settings.championDeadlineUtc
          ? utcToKuwaitLocalString(settings.championDeadlineUtc)
          : "",
        championResult: settings.championResult,
      }}
    />
  );
}
