import { NextResponse } from "next/server";
import { computeLeaderboard } from "@/lib/scoring";

// Always compute fresh — the leaderboard must reflect the latest results.
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await computeLeaderboard();
    return NextResponse.json({ rows });
  } catch {
    // DB unreachable — return empty so the client poller doesn't error out.
    return NextResponse.json({ rows: [] });
  }
}
