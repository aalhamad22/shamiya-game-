import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/settings";
import { currentPlayer } from "@/lib/auth";
import { formatKuwait, isLocked } from "@/lib/time";
import { scoreMatch } from "@/lib/scoring";
import { ROUND_LABELS, METHOD_SHORT } from "@/lib/constants";
import { teamFlag } from "@/lib/teams";

export const dynamic = "force-dynamic";

function winnerName(m: { teamA: string; teamB: string }, w: string | null) {
  if (w === "TEAM_A") return m.teamA;
  if (w === "TEAM_B") return m.teamB;
  if (w === "DRAW") return "Draw";
  return "—";
}

export default async function MyPage() {
  const player = await currentPlayer();
  if (!player) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-extrabold">My predictions</h1>
        <p className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-slate-500">
          Enter your name and PIN on the{" "}
          <Link href="/play" className="font-semibold text-pitch-700 underline">
            Play
          </Link>{" "}
          page first.
        </p>
      </div>
    );
  }

  const [settings, matches, preds] = await Promise.all([
    getSettings(),
    prisma.match.findMany({ orderBy: [{ kickoffUtc: "asc" }, { order: "asc" }] }),
    prisma.prediction.findMany({ where: { playerId: player.id } }),
  ]);

  const predByMatch = new Map(preds.map((p) => [p.matchId, p]));
  const predicted = matches.filter((m) => predByMatch.has(m.id));

  let totalMatchPoints = 0;
  for (const m of predicted) {
    totalMatchPoints += scoreMatch(predByMatch.get(m.id)!, m, settings);
  }

  const championBonus =
    settings.championEnabled &&
    settings.championResult &&
    player.championPick === settings.championResult
      ? settings.championBonusPoints
      : 0;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold">{player.name}</h1>
        <span className="rounded-full bg-pitch-50 px-4 py-1.5 text-sm font-bold text-pitch-700">
          {totalMatchPoints + championBonus} pts
        </span>
      </div>

      {settings.championEnabled && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm">
          🏆 Champion pick:{" "}
          <span className="font-bold">
            {player.championPick
              ? `${teamFlag(player.championPick)} ${player.championPick}`
              : "— none —"}
          </span>
          {championBonus > 0 && (
            <span className="ml-2 font-bold text-pitch-700">+{championBonus} ✓</span>
          )}
        </div>
      )}

      {predicted.length === 0 ? (
        <p className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-slate-500">
          You haven&apos;t made any picks yet.{" "}
          <Link href="/play" className="font-semibold text-pitch-700 underline">
            Make your picks →
          </Link>
        </p>
      ) : (
        <ul className="space-y-2">
          {predicted.map((m) => {
            const pred = predByMatch.get(m.id)!;
            const locked = isLocked(m.kickoffUtc);
            const finished = m.status === "FINISHED";
            const pts = scoreMatch(pred, m, settings);
            return (
              <li
                key={m.id}
                className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
              >
                <div className="flex items-center justify-between text-xs font-medium text-slate-400">
                  <span>{ROUND_LABELS[m.round]}</span>
                  <span>
                    {finished ? "Final" : locked ? "🔒 Locked" : "Open"}
                  </span>
                </div>
                <div className="mt-1 text-center font-bold">
                  {m.teamA} vs {m.teamB}
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                  <div className="rounded-lg bg-slate-50 px-3 py-2">
                    <div className="text-[11px] uppercase tracking-wide text-slate-400">
                      My pick
                    </div>
                    <div className="font-semibold">
                      {winnerName(m, pred.predictedWinner)}
                      {pred.predictedMethod ? ` · ${METHOD_SHORT[pred.predictedMethod]}` : ""}
                    </div>
                  </div>
                  <div className="rounded-lg bg-slate-50 px-3 py-2">
                    <div className="text-[11px] uppercase tracking-wide text-slate-400">
                      Result
                    </div>
                    <div className="font-semibold">
                      {finished
                        ? `${winnerName(m, m.resultWinner)}${
                            m.resultMethod ? ` · ${METHOD_SHORT[m.resultMethod]}` : ""
                          }`
                        : "—"}
                    </div>
                  </div>
                </div>
                <div className="mt-2 text-right">
                  {finished ? (
                    <span
                      className={[
                        "rounded-full px-3 py-1 text-sm font-bold",
                        pts > 0 ? "bg-pitch-50 text-pitch-700" : "bg-slate-100 text-slate-400",
                      ].join(" ")}
                    >
                      {pts} pt{pts === 1 ? "" : "s"}
                    </span>
                  ) : (
                    <span className="text-xs text-slate-400">{formatKuwait(m.kickoffUtc)}</span>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
