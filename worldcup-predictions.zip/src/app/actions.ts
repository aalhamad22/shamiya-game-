"use server";

// Player-facing server actions (called directly from client components).
// Each returns a small result object: { ok: boolean, error?: string }.

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/settings";
import {
  currentPlayerId,
  hashPin,
  verifyPin,
  setPlayerCookie,
  clearPlayerCookie,
} from "@/lib/auth";
import { isLocked } from "@/lib/time";
import type { Winner, Method } from "@prisma/client";

type Result = { ok: boolean; error?: string };

const VALID_WINNERS = ["TEAM_A", "TEAM_B", "DRAW"];
const VALID_METHODS = ["NINETY", "EXTRA_TIME", "PENALTIES"];

/**
 * Log in or register a player by name + 4-digit PIN.
 * - New name → creates the account with that PIN.
 * - Existing name → the PIN must match, otherwise access is denied.
 */
export async function authPlayer(nameRaw: string, pin: string): Promise<Result> {
  const name = (nameRaw || "").trim();
  if (name.length < 2 || name.length > 30) {
    return { ok: false, error: "Name must be 2–30 characters." };
  }
  if (!/^\d{4}$/.test(pin)) {
    return { ok: false, error: "PIN must be exactly 4 digits." };
  }

  try {
    // Case-insensitive name match so "Ali" and "ali" are the same person.
    const existing = await prisma.player.findFirst({
      where: { name: { equals: name, mode: "insensitive" } },
    });

    if (existing) {
      const good = await verifyPin(pin, existing.pinHash);
      if (!good) return { ok: false, error: "Wrong PIN for that name." };
      setPlayerCookie(existing.id);
      return { ok: true };
    }

    const player = await prisma.player.create({
      data: { name, pinHash: await hashPin(pin) },
    });
    setPlayerCookie(player.id);
    revalidatePath("/");
    return { ok: true };
  } catch (e) {
    // Almost always a database problem: DATABASE_URL not set, or the tables were
    // never created (run `prisma db push` + `npm run seed`).
    console.error("authPlayer DB error:", e);
    return {
      ok: false,
      error:
        "Couldn't save — the database isn't reachable yet. The site owner needs to finish the database setup (see README).",
    };
  }
}

export async function logoutPlayer(): Promise<Result> {
  clearPlayerCookie();
  return { ok: true };
}

/** Create or update the player's prediction for one match. */
export async function savePrediction(
  matchId: string,
  predictedWinner: string,
  predictedMethod: string | null
): Promise<Result> {
  const playerId = currentPlayerId();
  if (!playerId) return { ok: false, error: "Please enter your name and PIN first." };

  const match = await prisma.match.findUnique({ where: { id: matchId } });
  if (!match) return { ok: false, error: "Match not found." };

  // Per-match lock: once kickoff passes, predictions are read-only for everyone.
  if (isLocked(match.kickoffUtc)) {
    return { ok: false, error: "This match has kicked off — predictions are locked." };
  }

  if (!VALID_WINNERS.includes(predictedWinner)) {
    return { ok: false, error: "Invalid winner." };
  }
  // Draw is only allowed for non-knockout (group) games.
  if (predictedWinner === "DRAW" && match.isKnockout) {
    return { ok: false, error: "A knockout match cannot be a draw." };
  }

  // Method only applies to knockout games; ignored/cleared for group games.
  let method: Method | null = null;
  if (match.isKnockout) {
    if (!predictedMethod || !VALID_METHODS.includes(predictedMethod)) {
      return { ok: false, error: "Pick how they win: 90, extra time, or penalties." };
    }
    method = predictedMethod as Method;
  }

  await prisma.prediction.upsert({
    where: { playerId_matchId: { playerId, matchId } },
    update: { predictedWinner: predictedWinner as Winner, predictedMethod: method },
    create: {
      playerId,
      matchId,
      predictedWinner: predictedWinner as Winner,
      predictedMethod: method,
    },
  });

  revalidatePath("/play");
  revalidatePath("/my");
  return { ok: true };
}

/**
 * Set the player's one-time champion pick. This is a LOCK-ON-SELECTION pick:
 * once a player has chosen, it can never be changed (and it's also blocked after
 * the deadline, if one is set).
 */
export async function saveChampion(team: string): Promise<Result> {
  const playerId = currentPlayerId();
  if (!playerId) return { ok: false, error: "Please enter your name and PIN first." };

  const settings = await getSettings();
  if (!settings.championEnabled) return { ok: false, error: "Champion pick is disabled." };

  // Already locked in — can never be changed.
  const player = await prisma.player.findUnique({ where: { id: playerId } });
  if (player?.championPick) {
    return { ok: false, error: "Your champion pick is locked and can't be changed." };
  }

  if (settings.championDeadlineUtc && isLocked(settings.championDeadlineUtc)) {
    return { ok: false, error: "The champion pick deadline has passed." };
  }

  const t = (team || "").trim();
  if (!t) return { ok: false, error: "Pick a team." };

  await prisma.player.update({ where: { id: playerId }, data: { championPick: t } });
  revalidatePath("/play");
  revalidatePath("/my");
  revalidatePath("/");
  return { ok: true };
}
