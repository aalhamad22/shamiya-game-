import type { Metadata, Viewport } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "World Cup 2026 Predictions",
  description: "Predict the 2026 World Cup knockouts with your friends.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#15803d",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen">
        <header className="sticky top-0 z-10 border-b border-slate-200 bg-white/90 backdrop-blur">
          <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3">
            <Link href="/" className="text-lg font-extrabold tracking-tight">
              ⚽ WC 2026 <span className="text-pitch-700">Predictions</span>
            </Link>
            <nav className="flex items-center gap-3 text-sm font-medium">
              <Link href="/" className="text-slate-600 hover:text-slate-900">
                Home
              </Link>
              <Link href="/play" className="text-slate-600 hover:text-slate-900">
                Play
              </Link>
              <Link href="/my" className="text-slate-600 hover:text-slate-900">
                My picks
              </Link>
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-2xl px-4 pb-24 pt-4">{children}</main>
        <footer className="mx-auto max-w-2xl px-4 pb-8 pt-4 text-center text-xs text-slate-400">
          Times shown in Kuwait time (UTC+3). ·{" "}
          <Link href="/admin" className="underline hover:text-slate-600">
            Admin
          </Link>
        </footer>
      </body>
    </html>
  );
}
