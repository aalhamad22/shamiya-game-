import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/settings";
import { currentPlayer } from "@/lib/auth";
import { formatKuwait, isLocked } from "@/lib/time";
import AuthForm from "@/components/AuthForm";
import PredictionList, { PMatch, PPred } from "@/components/PredictionList";

export const dynamic = "force-dynamic";

export default async function PlayPage() {
  const player = await currentPlayer();

  if (!player) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-extrabold">Make your picks</h1>
        <AuthForm />
      </div>
    );
  }

  const [matches, preds, settings] = await Promise.all([
    prisma.match.findMany({ orderBy: [{ kickoffUtc: "asc" }, { order: "asc" }] }),
    prisma.prediction.findMany({ where: { playerId: player.id } }),
    getSettings(),
  ]);

  const predMap: Record<string, PPred> = {};
  for (const p of preds) {
    predMap[p.matchId] = { winner: p.predictedWinner, method: p.predictedMethod };
  }

  const pMatches: PMatch[] = matches.map((m) => ({
    id: m.id,
    round: m.round,
    teamA: m.teamA,
    teamB: m.teamB,
    kickoffIso: m.kickoffUtc.toISOString(),
    kickoffLabel: formatKuwait(m.kickoffUtc),
    isKnockout: m.isKnockout,
    locked: isLocked(m.kickoffUtc),
  }));

  // Distinct teams (for the champion dropdown), sorted alphabetically.
  const teamSet = new Set<string>();
  for (const m of matches) {
    teamSet.add(m.teamA);
    teamSet.add(m.teamB);
  }
  teamSet.delete("TBD");
  const teams = [...teamSet].sort((a, b) => a.localeCompare(b));

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-extrabold">Make your picks</h1>
      <PredictionList
        playerName={player.name}
        matches={pMatches}
        predictions={predMap}
        champion={{
          enabled: settings.championEnabled,
          // Locked once the player has chosen (one-time pick), or after the deadline.
          locked:
            player.championPick != null ||
            (settings.championDeadlineUtc ? isLocked(settings.championDeadlineUtc) : false),
          bonus: settings.championBonusPoints,
          deadlineLabel: settings.championDeadlineUtc
            ? formatKuwait(settings.championDeadlineUtc)
            : null,
          pick: player.championPick,
          teams,
        }}
      />
    </div>
  );
}
