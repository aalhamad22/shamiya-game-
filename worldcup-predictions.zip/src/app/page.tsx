import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { computeLeaderboard } from "@/lib/scoring";
import { getSettings } from "@/lib/settings";
import { formatKuwait } from "@/lib/time";
import { ROUND_LABELS, METHOD_SHORT } from "@/lib/constants";
import { teamFlag } from "@/lib/teams";
import Leaderboard from "@/components/Leaderboard";
import Countdown from "@/components/Countdown";

export const dynamic = "force-dynamic";

type Match = Awaited<ReturnType<typeof prisma.match.findMany>>[number];

export default async function HomePage() {
  // Degrade gracefully if the database can't be reached (e.g. before you've set
  // DATABASE_URL, or a brief Neon outage) — show empty states instead of a crash.
  let rows: Awaited<ReturnType<typeof computeLeaderboard>> = [];
  let matches: Match[] = [];
  let settings = {
    tournamentName: "World Cup 2026",
    championEnabled: true,
    championBonusPoints: 5,
  };
  let dbConnected = true;
  try {
    [rows, matches, settings] = await Promise.all([
      computeLeaderboard(),
      prisma.match.findMany({ orderBy: [{ kickoffUtc: "asc" }, { order: "asc" }] }),
      getSettings(),
    ]);
  } catch {
    dbConnected = false;
  }

  const now = Date.now();
  const upcoming = matches.filter((m) => m.kickoffUtc.getTime() > now).slice(0, 8);
  const recent = matches
    .filter((m) => m.status === "FINISHED")
    .sort((a, b) => b.kickoffUtc.getTime() - a.kickoffUtc.getTime())
    .slice(0, 5);

  return (
    <div className="space-y-8">
      {!dbConnected && (
        <div className="rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <strong>Database not connected.</strong> Set <code>DATABASE_URL</code> in
          your <code>.env</code> and run <code>npx prisma db push</code> +{" "}
          <code>npm run seed</code>. The page below shows empty placeholders until then.
        </div>
      )}
      <section className="rounded-2xl bg-gradient-to-br from-pitch-700 to-emerald-500 p-5 text-white shadow">
        <h1 className="text-2xl font-extrabold">{settings.tournamentName} Predictions</h1>
        <p className="mt-1 text-sm text-emerald-50">
          Predict each knockout match. +2 for the right winner, +1 for the right method.
          {settings.championEnabled && ` Pick the champion for +${settings.championBonusPoints}.`}
        </p>
        <Link
          href="/play"
          className="mt-4 inline-block rounded-xl bg-white px-5 py-2.5 font-bold text-pitch-700 shadow active:scale-95"
        >
          Make your picks →
        </Link>
      </section>

      <section>
        <h2 className="mb-3 text-lg font-bold">🏆 Leaderboard</h2>
        <Leaderboard initial={rows} />
      </section>

      <section>
        <h2 className="mb-3 text-lg font-bold">⏱️ Upcoming matches</h2>
        {upcoming.length === 0 ? (
          <p className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-slate-500">
            No upcoming matches scheduled yet.
          </p>
        ) : (
          <ul className="space-y-2">
            {upcoming.map((m) => (
              <li
                key={m.id}
                className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
              >
                <div className="flex items-center justify-between text-xs font-medium text-slate-400">
                  <span>{ROUND_LABELS[m.round]}</span>
                  <Countdown kickoffIso={m.kickoffUtc.toISOString()} />
                </div>
                <div className="mt-1 flex items-center justify-center gap-3 text-lg font-bold">
                  <span>
                    {teamFlag(m.teamA)} {m.teamA}
                  </span>
                  <span className="text-sm font-normal text-slate-400">vs</span>
                  <span>
                    {m.teamB} {teamFlag(m.teamB)}
                  </span>
                </div>
                <div className="mt-1 text-center text-xs text-slate-500">
                  {formatKuwait(m.kickoffUtc)}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      {recent.length > 0 && (
        <section>
          <h2 className="mb-3 text-lg font-bold">✅ Recent results</h2>
          <ul className="space-y-2">
            {recent.map((m) => {
              const winnerName =
                m.resultWinner === "TEAM_A"
                  ? m.teamA
                  : m.resultWinner === "TEAM_B"
                    ? m.teamB
                    : "Draw";
              return (
                <li
                  key={m.id}
                  className="flex items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm"
                >
                  <span className="text-slate-500">{ROUND_LABELS[m.round]}</span>
                  <span className="font-semibold">
                    {m.teamA} vs {m.teamB}
                  </span>
                  <span className="font-bold text-pitch-700">
                    {winnerName}
                    {m.resultMethod ? ` · ${METHOD_SHORT[m.resultMethod]}` : ""}
                  </span>
                </li>
              );
            })}
          </ul>
        </section>
      )}
    </div>
  );
}
