"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { savePrediction, saveChampion, logoutPlayer } from "@/app/actions";
import { ROUND_LABELS, METHOD_LABELS, METHODS } from "@/lib/constants";
import { teamFlag } from "@/lib/teams";
import Countdown from "./Countdown";

export type PMatch = {
  id: string;
  round: string;
  teamA: string;
  teamB: string;
  kickoffIso: string;
  kickoffLabel: string;
  isKnockout: boolean;
  locked: boolean;
};

export type PPred = { winner: string | null; method: string | null };

type Props = {
  playerName: string;
  matches: PMatch[];
  predictions: Record<string, PPred>;
  champion: {
    enabled: boolean;
    locked: boolean;
    bonus: number;
    deadlineLabel: string | null;
    pick: string | null;
    teams: string[];
  };
};

export default function PredictionList({
  playerName,
  matches,
  predictions,
  champion,
}: Props) {
  const router = useRouter();
  const open = matches.filter((m) => !m.locked);
  const locked = matches.filter((m) => m.locked);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between rounded-xl bg-white px-4 py-3 shadow-sm">
        <p className="text-sm">
          Playing as <span className="font-bold">{playerName}</span>
        </p>
        <button
          onClick={() => logoutPlayer().then(() => router.refresh())}
          className="text-sm font-medium text-slate-500 underline"
        >
          Switch user
        </button>
      </div>

      {champion.enabled && (
        <ChampionPicker champion={champion} onSaved={() => router.refresh()} />
      )}

      <section>
        <h2 className="mb-3 text-lg font-bold">Open matches</h2>
        {open.length === 0 ? (
          <p className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-slate-500">
            No open matches right now. Check back when the next round is scheduled.
          </p>
        ) : (
          <ul className="space-y-3">
            {open.map((m) => (
              <MatchCard key={m.id} match={m} pred={predictions[m.id]} />
            ))}
          </ul>
        )}
      </section>

      {locked.length > 0 && (
        <section>
          <h2 className="mb-3 text-lg font-bold text-slate-400">Locked matches</h2>
          <ul className="space-y-3 opacity-70">
            {locked.map((m) => (
              <MatchCard key={m.id} match={m} pred={predictions[m.id]} />
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

function MatchCard({ match, pred }: { match: PMatch; pred?: PPred }) {
  const [winner, setWinner] = useState<string | null>(pred?.winner ?? null);
  const [method, setMethod] = useState<string | null>(pred?.method ?? null);
  const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [msg, setMsg] = useState<string | null>(null);
  const [, start] = useTransition();

  function persist(nextWinner: string | null, nextMethod: string | null) {
    if (!nextWinner) return;
    if (match.isKnockout && !nextMethod) return; // wait for a complete pick
    setStatus("saving");
    start(async () => {
      const res = await savePrediction(match.id, nextWinner, nextMethod);
      if (res.ok) {
        setStatus("saved");
        setMsg(null);
      } else {
        setStatus("error");
        setMsg(res.error ?? "Could not save.");
      }
    });
  }

  function pickWinner(w: string) {
    if (match.locked) return;
    setWinner(w);
    persist(w, method);
  }
  function pickMethod(mth: string) {
    if (match.locked) return;
    setMethod(mth);
    persist(winner, mth);
  }

  const teamBtn = (value: string, label: string) => {
    const active = winner === value;
    return (
      <button
        onClick={() => pickWinner(value)}
        disabled={match.locked}
        className={[
          "flex-1 rounded-xl border-2 px-2 py-3 text-center text-base font-bold transition active:scale-95 disabled:active:scale-100",
          active
            ? "border-pitch-600 bg-pitch-50 text-pitch-700"
            : "border-slate-200 bg-white text-slate-700",
        ].join(" ")}
      >
        {label}
      </button>
    );
  };

  return (
    <li className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between text-xs font-medium text-slate-400">
        <span>{ROUND_LABELS[match.round]}</span>
        {match.locked ? (
          <span className="font-semibold text-rose-600">🔒 Locked</span>
        ) : (
          <Countdown kickoffIso={match.kickoffIso} />
        )}
      </div>

      <div className="mt-3 flex items-stretch gap-2">
        {teamBtn("TEAM_A", `${teamFlag(match.teamA)} ${match.teamA}`)}
        <div className="flex items-center text-xs text-slate-300">vs</div>
        {teamBtn("TEAM_B", `${teamFlag(match.teamB)} ${match.teamB}`)}
      </div>

      {!match.isKnockout && (
        <div className="mt-2">
          <button
            onClick={() => pickWinner("DRAW")}
            disabled={match.locked}
            className={[
              "w-full rounded-xl border-2 px-2 py-2 text-sm font-bold",
              winner === "DRAW"
                ? "border-pitch-600 bg-pitch-50 text-pitch-700"
                : "border-slate-200 bg-white text-slate-700",
            ].join(" ")}
          >
            Draw
          </button>
        </div>
      )}

      {match.isKnockout && winner && winner !== "DRAW" && (
        <div className="mt-3">
          <p className="mb-1 text-xs font-medium text-slate-500">How do they win?</p>
          <div className="flex gap-2">
            {METHODS.map((mth) => {
              const active = method === mth;
              return (
                <button
                  key={mth}
                  onClick={() => pickMethod(mth)}
                  disabled={match.locked}
                  className={[
                    "flex-1 rounded-lg border px-1 py-2 text-xs font-semibold",
                    active
                      ? "border-pitch-600 bg-pitch-50 text-pitch-700"
                      : "border-slate-200 bg-white text-slate-600",
                  ].join(" ")}
                >
                  {METHOD_LABELS[mth]}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="mt-2 flex items-center justify-between text-xs">
        <span className="text-slate-400">{match.kickoffLabel}</span>
        {status === "saving" && <span className="text-slate-400">Saving…</span>}
        {status === "saved" && <span className="font-semibold text-pitch-700">Saved ✓</span>}
        {status === "error" && <span className="font-semibold text-rose-600">{msg}</span>}
        {status === "idle" && pred?.winner && (
          <span className="font-semibold text-slate-400">Saved ✓</span>
        )}
      </div>
    </li>
  );
}

function ChampionPicker({
  champion,
  onSaved,
}: {
  champion: Props["champion"];
  onSaved: () => void;
}) {
  const [pick, setPick] = useState(champion.pick ?? "");
  const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [msg, setMsg] = useState<string | null>(null);
  const [, start] = useTransition();

  // Selecting in the dropdown only stages the choice; nothing is saved until the
  // player confirms. The pick is PERMANENT once locked, so we ask first.
  function lockIn() {
    if (!pick) return;
    const team = pick;
    const ok = window.confirm(
      `Lock in ${team} as your World Cup champion?\n\nThis is permanent — you will NOT be able to change it later.`
    );
    if (!ok) return;
    setStatus("saving");
    start(async () => {
      const res = await saveChampion(team);
      if (res.ok) {
        setStatus("saved");
        onSaved();
      } else {
        setStatus("error");
        setMsg(res.error ?? "Could not save.");
      }
    });
  }

  return (
    <section className="rounded-2xl border-2 border-amber-300 bg-amber-50 p-4">
      <h2 className="text-lg font-bold text-amber-900">
        🏆 Champion pick <span className="text-sm font-medium">(+{champion.bonus} pts)</span>
      </h2>
      {champion.locked ? (
        <p className="mt-1 text-sm text-amber-800">
          🔒 Locked in:{" "}
          <span className="font-bold">
            {champion.pick ? `${teamFlag(champion.pick)} ${champion.pick}` : "— none —"}
          </span>
          {champion.pick && (
            <span className="block text-xs text-amber-700">
              This pick is final and can&apos;t be changed.
            </span>
          )}
        </p>
      ) : (
        <>
          <p className="mt-1 text-sm text-amber-800">
            Who wins the whole tournament? <strong>This is a one-time pick</strong> — once you
            lock it in, you can&apos;t change it.
            {champion.deadlineLabel && ` (Also closes at ${champion.deadlineLabel}.)`}
          </p>
          <select
            value={pick}
            onChange={(e) => setPick(e.target.value)}
            className="mt-3 w-full rounded-xl border border-amber-300 bg-white px-4 py-3 text-base font-medium outline-none"
          >
            <option value="">— pick a team —</option>
            {champion.teams.map((t) => (
              <option key={t} value={t}>
                {teamFlag(t)} {t}
              </option>
            ))}
          </select>
          <button
            onClick={lockIn}
            disabled={!pick || status === "saving"}
            className="mt-2 w-full rounded-xl bg-amber-600 px-4 py-3 text-base font-bold text-white active:scale-95 disabled:opacity-50"
          >
            {status === "saving" ? "Locking…" : "🔒 Lock in my champion"}
          </button>
          <div className="mt-1 text-right text-xs">
            {status === "error" && <span className="font-semibold text-rose-600">{msg}</span>}
          </div>
        </>
      )}
    </section>
  );
}
