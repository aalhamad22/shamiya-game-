"use client";

import { useEffect, useState } from "react";
import type { LeaderboardRow } from "@/lib/scoring";
import { teamFlag } from "@/lib/teams";

// Public leaderboard that polls every 45s so standings update live once the
// admin enters results — no manual refresh needed.
export default function Leaderboard({ initial }: { initial: LeaderboardRow[] }) {
  const [rows, setRows] = useState<LeaderboardRow[]>(initial);
  const [openId, setOpenId] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<string>("");

  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const res = await fetch("/api/leaderboard", { cache: "no-store" });
        if (!res.ok) return;
        const data = await res.json();
        if (alive && Array.isArray(data.rows)) {
          setRows(data.rows);
          setUpdatedAt(new Date().toLocaleTimeString());
        }
      } catch {
        /* ignore transient network errors */
      }
    }
    const id = setInterval(load, 45000);
    return () => {
      alive = false;
      clearInterval(id);
    };
  }, []);

  if (rows.length === 0) {
    return (
      <p className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-slate-500">
        No players yet. Be the first to{" "}
        <a href="/play" className="font-semibold text-pitch-700 underline">
          make your picks
        </a>
        .
      </p>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <ul className="divide-y divide-slate-100">
        {rows.map((r) => {
          const medal = r.rank === 1 ? "🥇" : r.rank === 2 ? "🥈" : r.rank === 3 ? "🥉" : null;
          const open = openId === r.playerId;
          return (
            <li key={r.playerId}>
              <button
                onClick={() => setOpenId(open ? null : r.playerId)}
                className="flex w-full items-center gap-3 px-4 py-3 text-left active:bg-slate-50"
              >
                <span className="w-7 shrink-0 text-center text-sm font-bold tabular-nums text-slate-500">
                  {medal ?? r.rank}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-semibold">{r.name}</span>
                  {r.championPick ? (
                    <span className="block truncate text-xs text-amber-700">
                      🏆 {teamFlag(r.championPick)} {r.championPick}
                    </span>
                  ) : (
                    <span className="block truncate text-xs text-slate-400">
                      🏆 no champion pick
                    </span>
                  )}
                </span>
                <span className="shrink-0 rounded-full bg-pitch-50 px-3 py-1 text-sm font-bold tabular-nums text-pitch-700">
                  {r.total} pt{r.total === 1 ? "" : "s"}
                </span>
              </button>
              {open && (
                <div className="bg-slate-50 px-4 pb-3 pt-1 text-sm text-slate-600">
                  <div className="flex justify-between py-0.5">
                    <span>Match points</span>
                    <span className="tabular-nums">{r.matchPoints}</span>
                  </div>
                  {r.championPoints > 0 && (
                    <div className="flex justify-between py-0.5">
                      <span>Champion bonus</span>
                      <span className="tabular-nums">+{r.championPoints}</span>
                    </div>
                  )}
                  {r.adjustmentPoints !== 0 && (
                    <div className="flex justify-between py-0.5">
                      <span>Manual adjustments</span>
                      <span className="tabular-nums">{r.adjustmentPoints}</span>
                    </div>
                  )}
                  {r.championPick && (
                    <div className="flex justify-between py-0.5 text-slate-400">
                      <span>Champion pick</span>
                      <span>
                        {teamFlag(r.championPick)} {r.championPick}
                      </span>
                    </div>
                  )}
                </div>
              )}
            </li>
          );
        })}
      </ul>
      {updatedAt && (
        <div className="border-t border-slate-100 px-4 py-2 text-right text-[11px] text-slate-400">
          Auto-updates · last checked {updatedAt}
        </div>
      )}
    </div>
  );
}
