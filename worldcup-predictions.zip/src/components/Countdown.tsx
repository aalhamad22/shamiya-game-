"use client";

import { useEffect, useState } from "react";

// Live countdown to a kickoff. Once it passes, shows "Locked".
export default function Countdown({ kickoffIso }: { kickoffIso: string }) {
  const target = new Date(kickoffIso).getTime();
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  // Render nothing time-sensitive until mounted (avoids hydration mismatch).
  if (now === null) return <span className="tabular-nums text-slate-400">—</span>;

  const diff = target - now;
  if (diff <= 0) {
    return <span className="font-semibold text-rose-600">🔒 Locked</span>;
  }

  const s = Math.floor(diff / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;

  const parts = d > 0 ? `${d}d ${h}h ${m}m` : h > 0 ? `${h}h ${m}m ${sec}s` : `${m}m ${sec}s`;

  return <span className="tabular-nums font-semibold text-pitch-700">{parts}</span>;
}
