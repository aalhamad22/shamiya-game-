"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { authPlayer } from "@/app/actions";

// Name + 4-digit PIN. New name registers; existing name must match its PIN.
export default function AuthForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [pin, setPin] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function submit() {
    setError(null);
    start(async () => {
      try {
        const res = await authPlayer(name, pin);
        if (res.ok) router.refresh();
        else setError(res.error ?? "Something went wrong.");
      } catch {
        // The action POST itself failed (e.g. blocked by an origin check, or a
        // network/server error) — surface it instead of silently doing nothing.
        setError("Couldn't reach the server. Please try again in a moment.");
      }
    });
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h2 className="text-lg font-bold">Enter to play</h2>
      <p className="mt-1 text-sm text-slate-500">
        Pick a name and a 4-digit PIN. Your PIN keeps your picks yours — you&apos;ll
        need it to edit them later, so remember it.
      </p>
      <div className="mt-4 space-y-3">
        <label className="block">
          <span className="text-sm font-medium text-slate-600">Your name</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="off"
            maxLength={30}
            placeholder="e.g. Ali"
            className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-base outline-none focus:border-pitch-600 focus:ring-2 focus:ring-pitch-600/20"
          />
        </label>
        <label className="block">
          <span className="text-sm font-medium text-slate-600">4-digit PIN</span>
          <input
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
            inputMode="numeric"
            autoComplete="off"
            placeholder="••••"
            className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-base tracking-[0.5em] outline-none focus:border-pitch-600 focus:ring-2 focus:ring-pitch-600/20"
          />
        </label>
        {error && (
          <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>
        )}
        <button
          onClick={submit}
          disabled={pending}
          className="w-full rounded-xl bg-pitch-700 px-5 py-3 text-base font-bold text-white shadow active:scale-95 disabled:opacity-60"
        >
          {pending ? "Checking…" : "Enter"}
        </button>
      </div>
    </div>
  );
}
