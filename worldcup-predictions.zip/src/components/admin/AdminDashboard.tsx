"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { adminLogout } from "@/app/admin/actions";
import { ROUNDS, ROUND_LABELS } from "@/lib/constants";
import FixturesTab, { AMatch } from "./FixturesTab";
import AdjustmentsTab, { APlayer, AAdjustment } from "./AdjustmentsTab";
import SettingsTab, { ASettings } from "./SettingsTab";

type Props = {
  matches: AMatch[];
  players: APlayer[];
  adjustments: AAdjustment[];
  teams: string[];
  settings: ASettings;
};

type Tab = "fixtures" | "adjustments" | "settings";

export default function AdminDashboard({
  matches,
  players,
  adjustments,
  teams,
  settings,
}: Props) {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("fixtures");

  const tabs: { key: Tab; label: string }[] = [
    { key: "fixtures", label: "⚽ Fixtures & Results" },
    { key: "adjustments", label: "✏️ Adjustments" },
    { key: "settings", label: "⚙️ Settings" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold">Admin</h1>
        <button
          onClick={() => adminLogout().then(() => router.refresh())}
          className="text-sm font-medium text-slate-500 underline"
        >
          Log out
        </button>
      </div>

      <div className="flex gap-1 overflow-x-auto rounded-xl bg-slate-100 p-1 text-sm font-semibold">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={[
              "flex-1 whitespace-nowrap rounded-lg px-3 py-2",
              tab === t.key ? "bg-white text-slate-900 shadow" : "text-slate-500",
            ].join(" ")}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "fixtures" && (
        <FixturesTab matches={matches} rounds={ROUNDS} roundLabels={ROUND_LABELS} />
      )}
      {tab === "adjustments" && (
        <AdjustmentsTab players={players} adjustments={adjustments} />
      )}
      {tab === "settings" && (
        <SettingsTab settings={settings} teams={teams} players={players} />
      )}
    </div>
  );
}
