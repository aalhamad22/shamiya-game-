"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { updateSettings, setChampionResult } from "@/app/admin/actions";
import { teamFlag } from "@/lib/teams";
import type { APlayer } from "./AdjustmentsTab";

export type ASettings = {
  tournamentName: string;
  methodRequiresCorrectWinner: boolean;
  championEnabled: boolean;
  championBonusPoints: number;
  championDeadlineLocal: string;
  championResult: string | null;
};

export default function SettingsTab({
  settings,
  teams,
  players,
}: {
  settings: ASettings;
  teams: string[];
  players: APlayer[];
}) {
  const router = useRouter();
  const [form, setForm] = useState(settings);
  const [msg, setMsg] = useState<string | null>(null);
  const [champ, setChamp] = useState(settings.championResult ?? "");
  const [champMsg, setChampMsg] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function saveSettings() {
    setMsg(null);
    start(async () => {
      const res = await updateSettings({
        tournamentName: form.tournamentName,
        methodRequiresCorrectWinner: form.methodRequiresCorrectWinner,
        championEnabled: form.championEnabled,
        championBonusPoints: Number(form.championBonusPoints),
        championDeadlineLocal: form.championDeadlineLocal || null,
      });
      setMsg(res.ok ? "Settings saved ✓" : res.error ?? "Error");
      if (res.ok) router.refresh();
    });
  }

  function saveChampion() {
    setChampMsg(null);
    start(async () => {
      const res = await setChampionResult(champ || null);
      setChampMsg(res.ok ? "Champion result saved ✓" : res.error ?? "Error");
      if (res.ok) router.refresh();
    });
  }

  const field = "w-full rounded-lg border border-slate-300 px-3 py-2 text-sm";

  // How many players picked each team (handy when setting the champion result).
  const pickCounts = new Map<string, number>();
  for (const p of players) {
    if (p.championPick) pickCounts.set(p.championPick, (pickCounts.get(p.championPick) ?? 0) + 1);
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <h2 className="font-bold">Scoring & game settings</h2>
        <div className="mt-3 space-y-3">
          <label className="block text-sm">
            <span className="font-medium text-slate-600">Tournament name</span>
            <input
              value={form.tournamentName}
              onChange={(e) => setForm({ ...form, tournamentName: e.target.value })}
              className={field}
            />
          </label>

          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.methodRequiresCorrectWinner}
              onChange={(e) =>
                setForm({ ...form, methodRequiresCorrectWinner: e.target.checked })
              }
              className="mt-1 h-4 w-4"
            />
            <span>
              <span className="font-medium">Method point requires correct winner</span>
              <span className="block text-xs text-slate-500">
                On (default): the +1 method point only counts if the winner was also right
                (scores 3/2/0). Off: +1 is given whenever the method matches, even if the winner
                was wrong (scores 3/2/1/0).
              </span>
            </span>
          </label>

          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.championEnabled}
              onChange={(e) => setForm({ ...form, championEnabled: e.target.checked })}
              className="mt-1 h-4 w-4"
            />
            <span>
              <span className="font-medium">Enable champion pick bonus</span>
              <span className="block text-xs text-slate-500">
                Let players pick the overall winner for a bonus.
              </span>
            </span>
          </label>

          <label className="block text-sm">
            <span className="font-medium text-slate-600">Champion bonus points</span>
            <input
              type="number"
              value={form.championBonusPoints}
              onChange={(e) =>
                setForm({ ...form, championBonusPoints: Number(e.target.value) })
              }
              className={field}
            />
          </label>

          <label className="block text-sm">
            <span className="font-medium text-slate-600">
              Champion pick deadline (Kuwait time)
            </span>
            <input
              type="datetime-local"
              value={form.championDeadlineLocal}
              onChange={(e) => setForm({ ...form, championDeadlineLocal: e.target.value })}
              className={field}
            />
            <span className="text-xs text-slate-400">
              Leave blank for no deadline. Default is the first Round of 32 kickoff.
            </span>
          </label>

          {msg && <p className="text-sm font-semibold text-pitch-700">{msg}</p>}
          <button
            onClick={saveSettings}
            disabled={pending}
            className="w-full rounded-lg bg-pitch-700 px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
          >
            Save settings
          </button>
        </div>
      </div>

      <div className="rounded-2xl border-2 border-amber-300 bg-amber-50 p-4">
        <h2 className="font-bold text-amber-900">🏆 Champion result</h2>
        <p className="mt-1 text-xs text-amber-800">
          Set which team won the tournament to award the champion bonus. Clear it to remove the
          bonus again.
        </p>
        <select value={champ} onChange={(e) => setChamp(e.target.value)} className={`${field} mt-3`}>
          <option value="">— not decided yet —</option>
          {teams.map((t) => (
            <option key={t} value={t}>
              {teamFlag(t)} {t}
              {pickCounts.get(t) ? ` (${pickCounts.get(t)} picked)` : ""}
            </option>
          ))}
        </select>
        {champMsg && <p className="mt-2 text-sm font-semibold text-amber-800">{champMsg}</p>}
        <button
          onClick={saveChampion}
          disabled={pending}
          className="mt-2 w-full rounded-lg bg-amber-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
        >
          Save champion result
        </button>
      </div>
    </div>
  );
}
