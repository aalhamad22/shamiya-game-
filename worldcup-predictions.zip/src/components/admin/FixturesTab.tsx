"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  createMatch,
  updateMatch,
  deleteMatch,
  setResult,
  getMatchPredictions,
} from "@/app/admin/actions";
import { METHOD_LABELS, METHODS, METHOD_SHORT } from "@/lib/constants";

export type AMatch = {
  id: string;
  round: string;
  teamA: string;
  teamB: string;
  kickoffLocal: string;
  kickoffLabel: string;
  isKnockout: boolean;
  status: string;
  resultWinner: string | null;
  resultMethod: string | null;
};

type Props = {
  matches: AMatch[];
  rounds: readonly string[];
  roundLabels: Record<string, string>;
};

const EMPTY = {
  round: "ROUND_OF_32",
  teamA: "",
  teamB: "",
  kickoffLocal: "",
  isKnockout: true,
};

export default function FixturesTab({ matches, rounds, roundLabels }: Props) {
  const [adding, setAdding] = useState(false);

  return (
    <div className="space-y-4">
      <button
        onClick={() => setAdding((v) => !v)}
        className="w-full rounded-xl bg-pitch-700 px-4 py-3 font-bold text-white active:scale-95"
      >
        {adding ? "Close" : "＋ Add a match"}
      </button>

      {adding && (
        <MatchForm
          initial={EMPTY}
          rounds={rounds}
          roundLabels={roundLabels}
          submitLabel="Create match"
          onDone={() => setAdding(false)}
        />
      )}

      {matches.length === 0 ? (
        <p className="rounded-xl border border-dashed border-slate-300 p-6 text-center text-slate-500">
          No matches yet. Add one above (or run the seed script).
        </p>
      ) : (
        <ul className="space-y-3">
          {matches.map((m) => (
            <MatchRow key={m.id} match={m} rounds={rounds} roundLabels={roundLabels} />
          ))}
        </ul>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------

function MatchRow({
  match,
  rounds,
  roundLabels,
}: {
  match: AMatch;
  rounds: readonly string[];
  roundLabels: Record<string, string>;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [viewing, setViewing] = useState(false);
  const [preds, setPreds] = useState<
    { name: string; winner: string; method: string | null }[] | null
  >(null);
  const [, start] = useTransition();

  const finished = match.status === "FINISHED";
  const resultText = finished
    ? `${
        match.resultWinner === "TEAM_A"
          ? match.teamA
          : match.resultWinner === "TEAM_B"
            ? match.teamB
            : "Draw"
      }${match.resultMethod ? ` · ${METHOD_SHORT[match.resultMethod]}` : ""}`
    : null;

  function remove() {
    if (!confirm(`Delete ${match.teamA} vs ${match.teamB}? This removes its predictions too.`))
      return;
    start(async () => {
      await deleteMatch(match.id);
      router.refresh();
    });
  }

  function toggleView() {
    if (viewing) {
      setViewing(false);
      return;
    }
    setViewing(true);
    start(async () => {
      const res = await getMatchPredictions(match.id);
      if (res.ok) setPreds(res.rows ?? []);
    });
  }

  return (
    <li className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-xs font-medium text-slate-400">
            {roundLabels[match.round]} · {match.isKnockout ? "Knockout" : "Group"}
          </div>
          <div className="font-bold">
            {match.teamA} vs {match.teamB}
          </div>
          <div className="text-xs text-slate-500">{match.kickoffLabel}</div>
        </div>
        <div className="text-right">
          {finished ? (
            <span className="rounded-full bg-pitch-50 px-3 py-1 text-xs font-bold text-pitch-700">
              {resultText}
            </span>
          ) : (
            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-500">
              Scheduled
            </span>
          )}
        </div>
      </div>

      <ResultEditor match={match} />

      <div className="mt-3 flex flex-wrap gap-3 text-sm font-medium">
        <button onClick={() => setEditing((v) => !v)} className="text-slate-600 underline">
          {editing ? "Cancel edit" : "Edit fixture"}
        </button>
        <button onClick={toggleView} className="text-slate-600 underline">
          {viewing ? "Hide predictions" : "View predictions"}
        </button>
        <button onClick={remove} className="text-rose-600 underline">
          Delete
        </button>
      </div>

      {editing && (
        <div className="mt-3 border-t border-slate-100 pt-3">
          <MatchForm
            initial={{
              round: match.round,
              teamA: match.teamA,
              teamB: match.teamB,
              kickoffLocal: match.kickoffLocal,
              isKnockout: match.isKnockout,
            }}
            rounds={rounds}
            roundLabels={roundLabels}
            submitLabel="Save changes"
            matchId={match.id}
            onDone={() => setEditing(false)}
          />
        </div>
      )}

      {viewing && (
        <div className="mt-3 border-t border-slate-100 pt-3 text-sm">
          {preds === null ? (
            <p className="text-slate-400">Loading…</p>
          ) : preds.length === 0 ? (
            <p className="text-slate-400">No predictions for this match yet.</p>
          ) : (
            <ul className="space-y-1">
              {preds.map((p, i) => (
                <li key={i} className="flex justify-between">
                  <span>{p.name}</span>
                  <span className="font-medium text-slate-600">
                    {p.winner === "TEAM_A"
                      ? match.teamA
                      : p.winner === "TEAM_B"
                        ? match.teamB
                        : "Draw"}
                    {p.method ? ` · ${METHOD_SHORT[p.method]}` : ""}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </li>
  );
}

// ---------------------------------------------------------------------------

function ResultEditor({ match }: { match: AMatch }) {
  const router = useRouter();
  const [winner, setWinner] = useState<string>(match.resultWinner ?? "");
  const [method, setMethod] = useState<string>(match.resultMethod ?? "");
  const [msg, setMsg] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function save() {
    setMsg(null);
    start(async () => {
      const res = await setResult(match.id, winner, winner && winner !== "DRAW" ? method : null);
      if (res.ok) {
        setMsg("Saved ✓");
        router.refresh();
      } else {
        setMsg(res.error ?? "Error");
      }
    });
  }

  const needsMethod = match.isKnockout && winner && winner !== "DRAW";

  return (
    <div className="mt-3 rounded-xl bg-slate-50 p-3">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
        Enter result
      </p>
      <div className="flex flex-wrap gap-2">
        <select
          value={winner}
          onChange={(e) => setWinner(e.target.value)}
          className="flex-1 rounded-lg border border-slate-300 px-2 py-2 text-sm"
        >
          <option value="">— winner —</option>
          <option value="TEAM_A">{match.teamA}</option>
          <option value="TEAM_B">{match.teamB}</option>
          {!match.isKnockout && <option value="DRAW">Draw</option>}
        </select>
        {needsMethod && (
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value)}
            className="flex-1 rounded-lg border border-slate-300 px-2 py-2 text-sm"
          >
            <option value="">— method —</option>
            {METHODS.map((mth) => (
              <option key={mth} value={mth}>
                {METHOD_LABELS[mth]}
              </option>
            ))}
          </select>
        )}
        <button
          onClick={save}
          disabled={pending}
          className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
        >
          Save
        </button>
      </div>
      {msg && <p className="mt-1 text-xs font-semibold text-pitch-700">{msg}</p>}
    </div>
  );
}

// ---------------------------------------------------------------------------

function MatchForm({
  initial,
  rounds,
  roundLabels,
  submitLabel,
  matchId,
  onDone,
}: {
  initial: typeof EMPTY;
  rounds: readonly string[];
  roundLabels: Record<string, string>;
  submitLabel: string;
  matchId?: string;
  onDone: () => void;
}) {
  const router = useRouter();
  const [form, setForm] = useState(initial);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function submit() {
    setError(null);
    start(async () => {
      const res = matchId
        ? await updateMatch(matchId, form)
        : await createMatch(form);
      if (res.ok) {
        router.refresh();
        onDone();
      } else {
        setError(res.error ?? "Error");
      }
    });
  }

  const field = "w-full rounded-lg border border-slate-300 px-3 py-2 text-sm";

  return (
    <div className="space-y-2 rounded-xl bg-slate-50 p-3">
      <select
        value={form.round}
        onChange={(e) => setForm({ ...form, round: e.target.value })}
        className={field}
      >
        {rounds.map((r) => (
          <option key={r} value={r}>
            {roundLabels[r]}
          </option>
        ))}
      </select>
      <div className="flex gap-2">
        <input
          value={form.teamA}
          onChange={(e) => setForm({ ...form, teamA: e.target.value })}
          placeholder="Team A"
          className={field}
        />
        <input
          value={form.teamB}
          onChange={(e) => setForm({ ...form, teamB: e.target.value })}
          placeholder="Team B"
          className={field}
        />
      </div>
      <label className="block text-xs font-medium text-slate-500">
        Kickoff (Kuwait time)
        <input
          type="datetime-local"
          value={form.kickoffLocal}
          onChange={(e) => setForm({ ...form, kickoffLocal: e.target.value })}
          className={field}
        />
      </label>
      <label className="flex items-center gap-2 text-sm text-slate-600">
        <input
          type="checkbox"
          checked={form.isKnockout}
          onChange={(e) => setForm({ ...form, isKnockout: e.target.checked })}
          className="h-4 w-4"
        />
        Knockout match (uncheck for a group game where a draw is possible)
      </label>
      {error && <p className="rounded bg-rose-50 px-2 py-1 text-xs text-rose-700">{error}</p>}
      <button
        onClick={submit}
        disabled={pending}
        className="w-full rounded-lg bg-pitch-700 px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
      >
        {pending ? "Saving…" : submitLabel}
      </button>
    </div>
  );
}
