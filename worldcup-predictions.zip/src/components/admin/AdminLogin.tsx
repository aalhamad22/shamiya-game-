"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { adminLogin } from "@/app/admin/actions";

export default function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function submit() {
    setError(null);
    start(async () => {
      const res = await adminLogin(password);
      if (res.ok) router.refresh();
      else setError(res.error ?? "Login failed.");
    });
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-sm text-slate-500">Enter the admin password to manage the game.</p>
      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && submit()}
        placeholder="Admin password"
        className="mt-3 w-full rounded-xl border border-slate-300 px-4 py-3 text-base outline-none focus:border-pitch-600 focus:ring-2 focus:ring-pitch-600/20"
      />
      {error && <p className="mt-2 rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>}
      <button
        onClick={submit}
        disabled={pending}
        className="mt-3 w-full rounded-xl bg-slate-900 px-5 py-3 font-bold text-white active:scale-95 disabled:opacity-60"
      >
        {pending ? "Checking…" : "Log in"}
      </button>
    </div>
  );
}
