"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addAdjustment, deleteAdjustment } from "@/app/admin/actions";

export type APlayer = { id: string; name: string; championPick: string | null };
export type AAdjustment = {
  id: string;
  playerName: string;
  points: number;
  reason: string;
  createdLabel: string;
};

export default function AdjustmentsTab({
  players,
  adjustments,
}: {
  players: APlayer[];
  adjustments: AAdjustment[];
}) {
  const router = useRouter();
  const [playerId, setPlayerId] = useState("");
  const [points, setPoints] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function submit() {
    setError(null);
    const n = parseInt(points, 10);
    if (!playerId) return setError("Pick a player.");
    if (!Number.isInteger(n) || n === 0) return setError("Points must be a non-zero whole number.");
    start(async () => {
      const res = await addAdjustment(playerId, n, reason);
      if (res.ok) {
        setPoints("");
        setReason("");
        router.refresh();
      } else {
        setError(res.error ?? "Error");
      }
    });
  }

  function remove(id: string) {
    if (!confirm("Remove this adjustment?")) return;
    start(async () => {
      await deleteAdjustment(id);
      router.refresh();
    });
  }

  const field = "w-full rounded-lg border border-slate-300 px-3 py-2 text-sm";

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <h2 className="font-bold">Manually adjust points</h2>
        <p className="mt-1 text-xs text-slate-500">
          Add or subtract points for a player with a note. Use negative numbers to subtract.
          Every change is logged below.
        </p>
        <div className="mt-3 space-y-2">
          <select value={playerId} onChange={(e) => setPlayerId(e.target.value)} className={field}>
            <option value="">— pick a player —</option>
            {players.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <input
            value={points}
            onChange={(e) => setPoints(e.target.value.replace(/[^\d-]/g, ""))}
            inputMode="numeric"
            placeholder="Points (e.g. 2 or -1)"
            className={field}
          />
          <input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Reason (e.g. corrected wrong result)"
            className={field}
          />
          {error && <p className="rounded bg-rose-50 px-2 py-1 text-xs text-rose-700">{error}</p>}
          <button
            onClick={submit}
            disabled={pending}
            className="w-full rounded-lg bg-pitch-700 px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
          >
            Apply adjustment
          </button>
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
        <h2 className="font-bold">Adjustment log</h2>
        {adjustments.length === 0 ? (
          <p className="mt-2 text-sm text-slate-400">No adjustments yet.</p>
        ) : (
          <ul className="mt-2 divide-y divide-slate-100">
            {adjustments.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                <div className="min-w-0">
                  <div className="font-semibold">
                    {a.playerName}{" "}
                    <span className={a.points >= 0 ? "text-pitch-700" : "text-rose-600"}>
                      {a.points >= 0 ? `+${a.points}` : a.points}
                    </span>
                  </div>
                  <div className="truncate text-xs text-slate-500">{a.reason}</div>
                  <div className="text-[11px] text-slate-400">{a.createdLabel}</div>
                </div>
                <button
                  onClick={() => remove(a.id)}
                  className="shrink-0 text-xs font-medium text-rose-600 underline"
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
