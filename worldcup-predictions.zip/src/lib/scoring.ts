// ============================================================================
// SCORING LOGIC
// ============================================================================
// This is the file to edit if you want to change how points work.
//
// Per-match scoring (knockout games):
//   +2 points  ... correct WINNER (which team advances)
//   +1 point   ... correct METHOD (90 mins / extra time / penalties)
//
// The "methodRequiresCorrectWinner" setting controls when the +1 is given:
//   true  (default): the +1 method point only counts if the winner was ALSO
//                    correct. Possible match scores: 3, 2, or 0.
//   false:           the +1 method point counts whenever the predicted method
//                    matches the actual method, regardless of the winner.
//                    Possible match scores: 3, 2, 1, or 0.
//
// Non-knockout (group) games:
//   Draws are allowed as an outcome. Method scoring is disabled. A correct
//   result (the right team OR a correctly-predicted draw) is worth +2. Max 2.
//
// Champion bonus (optional, configurable): +championBonusPoints if a player's
// championPick equals the tournament's championResult. Handled in the
// leaderboard builder below, not in scoreMatch (it's not tied to one match).
// ============================================================================

import { prisma } from "./prisma";
import { getSettings } from "./settings";
import type {
  Match,
  Prediction,
  Settings,
  Winner,
  Method,
} from "@prisma/client";

export const WINNER_POINTS = 2;
export const METHOD_POINTS = 1;

/**
 * Points a single prediction earns for a single match.
 * Returns 0 if the match isn't finished yet or there's no usable result.
 */
export function scoreMatch(
  prediction: Pick<Prediction, "predictedWinner" | "predictedMethod">,
  match: Pick<Match, "status" | "resultWinner" | "resultMethod" | "isKnockout">,
  settings: Pick<Settings, "methodRequiresCorrectWinner">
): number {
  // No result entered yet → no points.
  if (match.status !== "FINISHED" || match.resultWinner == null) return 0;

  const winnerCorrect: boolean = prediction.predictedWinner === match.resultWinner;

  // ---- Group (non-knockout) games: result only, no method ----
  if (!match.isKnockout) {
    return winnerCorrect ? WINNER_POINTS : 0;
  }

  // ---- Knockout games ----
  let points = 0;
  if (winnerCorrect) points += WINNER_POINTS;

  const methodCorrect: boolean =
    match.resultMethod != null &&
    prediction.predictedMethod != null &&
    prediction.predictedMethod === match.resultMethod;

  if (methodCorrect) {
    if (settings.methodRequiresCorrectWinner) {
      // Default: only award the method point when the winner is also correct.
      if (winnerCorrect) points += METHOD_POINTS;
    } else {
      // Award the method point on its own merit.
      points += METHOD_POINTS;
    }
  }

  return points;
}

// ---------------------------------------------------------------------------
// Leaderboard
// ---------------------------------------------------------------------------

export type MatchBreakdownRow = {
  matchId: string;
  label: string; // "Brazil vs Japan"
  round: string;
  points: number;
  finished: boolean;
};

export type LeaderboardRow = {
  rank: number; // 1-based, ties share a rank
  playerId: string;
  name: string;
  matchPoints: number;
  adjustmentPoints: number;
  championPoints: number;
  total: number;
  championPick: string | null;
};

export type PlayerScoreDetail = {
  playerId: string;
  name: string;
  matchPoints: number;
  adjustmentPoints: number;
  championPoints: number;
  total: number;
  championPick: string | null;
  matches: MatchBreakdownRow[];
};

/**
 * Compute every player's full score breakdown from scratch.
 * Pure read — nothing is stored; the leaderboard is always derived live so it
 * stays correct after the admin edits a result, an adjustment, or a setting.
 */
export async function computePlayerScores(): Promise<PlayerScoreDetail[]> {
  const settings = await getSettings();

  const [players, matches] = await Promise.all([
    prisma.player.findMany({
      include: { predictions: true, adjustments: true },
      orderBy: { createdAt: "asc" },
    }),
    prisma.match.findMany({ orderBy: [{ kickoffUtc: "asc" }, { order: "asc" }] }),
  ]);

  const matchById = new Map(matches.map((m) => [m.id, m]));

  return players.map((player) => {
    const breakdown: MatchBreakdownRow[] = [];
    let matchPoints = 0;

    for (const pred of player.predictions) {
      const match = matchById.get(pred.matchId);
      if (!match) continue;
      const pts = scoreMatch(pred, match, settings);
      matchPoints += pts;
      breakdown.push({
        matchId: match.id,
        label: `${match.teamA} vs ${match.teamB}`,
        round: match.round,
        points: pts,
        finished: match.status === "FINISHED",
      });
    }

    const adjustmentPoints = player.adjustments.reduce((s, a) => s + a.points, 0);

    // Champion bonus: only when enabled, a result is set, and the pick matches.
    let championPoints = 0;
    if (
      settings.championEnabled &&
      settings.championResult &&
      player.championPick &&
      player.championPick === settings.championResult
    ) {
      championPoints = settings.championBonusPoints;
    }

    return {
      playerId: player.id,
      name: player.name,
      matchPoints,
      adjustmentPoints,
      championPoints,
      total: matchPoints + adjustmentPoints + championPoints,
      championPick: player.championPick,
      matches: breakdown,
    };
  });
}

/** Ranked leaderboard. Ties share a rank (standard competition ranking). */
export async function computeLeaderboard(): Promise<LeaderboardRow[]> {
  const details = await computePlayerScores();

  details.sort((a, b) => b.total - a.total || a.name.localeCompare(b.name));

  const rows: LeaderboardRow[] = [];
  let lastTotal: number | null = null;
  let lastRank = 0;
  details.forEach((d, i) => {
    const rank = lastTotal !== null && d.total === lastTotal ? lastRank : i + 1;
    lastTotal = d.total;
    lastRank = rank;
    rows.push({
      rank,
      playerId: d.playerId,
      name: d.name,
      matchPoints: d.matchPoints,
      adjustmentPoints: d.adjustmentPoints,
      championPoints: d.championPoints,
      total: d.total,
      championPick: d.championPick,
    });
  });
  return rows;
}
