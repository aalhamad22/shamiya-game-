// Team display helpers: 3-letter codes and flag emoji.
// Add new teams here as the bracket fills in. If a team isn't listed we fall
// back to the first 3 letters of the name and a generic flag.

type TeamInfo = { code: string; flag: string };

const TEAMS: Record<string, TeamInfo> = {
  "South Africa": { code: "RSA", flag: "🇿🇦" },
  Canada: { code: "CAN", flag: "🇨🇦" },
  Brazil: { code: "BRA", flag: "🇧🇷" },
  Japan: { code: "JPN", flag: "🇯🇵" },
  Germany: { code: "GER", flag: "🇩🇪" },
  Paraguay: { code: "PAR", flag: "🇵🇾" },
  Netherlands: { code: "NED", flag: "🇳🇱" },
  Morocco: { code: "MAR", flag: "🇲🇦" },
  "Ivory Coast": { code: "CIV", flag: "🇨🇮" },
  Norway: { code: "NOR", flag: "🇳🇴" },
  France: { code: "FRA", flag: "🇫🇷" },
  Sweden: { code: "SWE", flag: "🇸🇪" },
  Mexico: { code: "MEX", flag: "🇲🇽" },
  Ecuador: { code: "ECU", flag: "🇪🇨" },
  England: { code: "ENG", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿" },
  "DR Congo": { code: "COD", flag: "🇨🇩" },
  Belgium: { code: "BEL", flag: "🇧🇪" },
  Senegal: { code: "SEN", flag: "🇸🇳" },
  "United States": { code: "USA", flag: "🇺🇸" },
  "Bosnia and Herzegovina": { code: "BIH", flag: "🇧🇦" },
  Spain: { code: "ESP", flag: "🇪🇸" },
  Austria: { code: "AUT", flag: "🇦🇹" },
  Switzerland: { code: "SUI", flag: "🇨🇭" },
  Algeria: { code: "ALG", flag: "🇩🇿" },
  Portugal: { code: "POR", flag: "🇵🇹" },
  Croatia: { code: "CRO", flag: "🇭🇷" },
  Australia: { code: "AUS", flag: "🇦🇺" },
  Egypt: { code: "EGY", flag: "🇪🇬" },
  Argentina: { code: "ARG", flag: "🇦🇷" },
  "Cabo Verde": { code: "CPV", flag: "🇨🇻" },
  Colombia: { code: "COL", flag: "🇨🇴" },
  Ghana: { code: "GHA", flag: "🇬🇭" },
  TBD: { code: "TBD", flag: "🏳️" },
};

export function teamCode(name: string): string {
  return TEAMS[name]?.code ?? name.slice(0, 3).toUpperCase();
}

export function teamFlag(name: string): string {
  return TEAMS[name]?.flag ?? "🏳️";
}

export function teamLabel(name: string): string {
  return `${teamFlag(name)} ${name}`;
}
