// Time zone handling.
//
// RULE: the database always stores UTC. Users always see Kuwait time.
// Kuwait (Asia/Kuwait) is UTC+3 all year round — it does NOT observe daylight
// saving — so the offset is a constant +3 hours. That makes the conversion a
// simple, reliable arithmetic shift with no tz database needed.

export const KUWAIT_OFFSET_HOURS = 3;
const MS_PER_HOUR = 60 * 60 * 1000;

/**
 * Convert a "Kuwait local" datetime-local string (e.g. "2026-06-28T20:00")
 * — which is what the admin types into the form — into a real UTC Date.
 * Kuwait local 20:00 == 17:00 UTC.
 */
export function kuwaitLocalStringToUtc(local: string): Date {
  // Parse the wall-clock fields directly; do NOT let the runtime guess a zone.
  const m = local.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
  if (!m) throw new Error(`Invalid datetime-local string: ${local}`);
  const [, y, mo, d, h, mi] = m;
  // Build the equivalent UTC instant by subtracting the Kuwait offset.
  const asUtcMs = Date.UTC(+y, +mo - 1, +d, +h, +mi);
  return new Date(asUtcMs - KUWAIT_OFFSET_HOURS * MS_PER_HOUR);
}

/**
 * Convert a UTC Date into the "YYYY-MM-DDTHH:mm" string that a
 * <input type="datetime-local"> expects, expressed in Kuwait wall-clock time.
 */
export function utcToKuwaitLocalString(date: Date): string {
  const shifted = new Date(date.getTime() + KUWAIT_OFFSET_HOURS * MS_PER_HOUR);
  const p = (n: number) => String(n).padStart(2, "0");
  return (
    `${shifted.getUTCFullYear()}-${p(shifted.getUTCMonth() + 1)}-${p(shifted.getUTCDate())}` +
    `T${p(shifted.getUTCHours())}:${p(shifted.getUTCMinutes())}`
  );
}

/** Human-friendly Kuwait-time label, e.g. "Sun 28 Jun, 20:00 (Kuwait)". */
export function formatKuwait(date: Date): string {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kuwait",
    weekday: "short",
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(date) + " (Kuwait)";
}

/** True once the match kickoff has passed (i.e. predictions are locked). */
export function isLocked(kickoffUtc: Date, now: Date = new Date()): boolean {
  return now.getTime() >= kickoffUtc.getTime();
}
