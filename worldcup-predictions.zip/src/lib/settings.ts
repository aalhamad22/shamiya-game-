import { prisma } from "./prisma";
import type { Settings } from "@prisma/client";

// Always returns the single settings row, creating it with defaults if missing.
export async function getSettings(): Promise<Settings> {
  const existing = await prisma.settings.findUnique({ where: { id: 1 } });
  if (existing) return existing;
  return prisma.settings.create({ data: { id: 1 } });
}
