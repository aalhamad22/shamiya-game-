// Display labels and ordering for enums. Kept in one place so the UI and admin
// forms stay consistent.

export const ROUNDS = [
  "ROUND_OF_32",
  "ROUND_OF_16",
  "QUARTER_FINAL",
  "SEMI_FINAL",
  "THIRD_PLACE",
  "FINAL",
] as const;
export type RoundKey = (typeof ROUNDS)[number];

export const ROUND_LABELS: Record<string, string> = {
  ROUND_OF_32: "Round of 32",
  ROUND_OF_16: "Round of 16",
  QUARTER_FINAL: "Quarter-final",
  SEMI_FINAL: "Semi-final",
  THIRD_PLACE: "Third-place",
  FINAL: "Final",
};

export const METHODS = ["NINETY", "EXTRA_TIME", "PENALTIES"] as const;
export type MethodKey = (typeof METHODS)[number];

export const METHOD_LABELS: Record<string, string> = {
  NINETY: "90 mins",
  EXTRA_TIME: "Extra time",
  PENALTIES: "Penalties",
};

export const METHOD_SHORT: Record<string, string> = {
  NINETY: "90'",
  EXTRA_TIME: "AET",
  PENALTIES: "PENS",
};

export const WINNER_LABELS: Record<string, string> = {
  TEAM_A: "Team A",
  TEAM_B: "Team B",
  DRAW: "Draw",
};
