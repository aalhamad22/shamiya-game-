// Authentication helpers.
//
// There are two independent identities:
//   1. ADMIN  — a single password (env ADMIN_PASSWORD). Used to reach /admin.
//   2. PLAYER — a name + 4-digit PIN. The PIN is bcrypt-hashed in the DB.
//
// We avoid a full auth library. After a successful login we set an httpOnly,
// signed cookie. The signature (HMAC-SHA256 with SESSION_SECRET) prevents a
// user from forging a cookie for someone else.

import { cookies } from "next/headers";
import crypto from "crypto";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";

const ADMIN_COOKIE = "wc_admin";
const PLAYER_COOKIE = "wc_player";
const ONE_MONTH = 60 * 60 * 24 * 30;

function secret(): string {
  return process.env.SESSION_SECRET || "dev-insecure-secret-change-me";
}

// value.signature  — signature = HMAC(value)
function sign(value: string): string {
  const sig = crypto.createHmac("sha256", secret()).update(value).digest("hex");
  return `${value}.${sig}`;
}

function verify(signed: string | undefined): string | null {
  if (!signed) return null;
  const idx = signed.lastIndexOf(".");
  if (idx < 0) return null;
  const value = signed.slice(0, idx);
  const sig = signed.slice(idx + 1);
  const expected = crypto.createHmac("sha256", secret()).update(value).digest("hex");
  // timing-safe compare
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return value;
}

// ---------------------------------------------------------------------------
// Admin
// ---------------------------------------------------------------------------

export function checkAdminPassword(password: string): boolean {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return false;
  const a = Buffer.from(password);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function setAdminCookie() {
  cookies().set(ADMIN_COOKIE, sign("admin"), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: ONE_MONTH,
  });
}

export function clearAdminCookie() {
  cookies().delete(ADMIN_COOKIE);
}

export function isAdmin(): boolean {
  return verify(cookies().get(ADMIN_COOKIE)?.value) === "admin";
}

// ---------------------------------------------------------------------------
// Player
// ---------------------------------------------------------------------------

export async function hashPin(pin: string): Promise<string> {
  return bcrypt.hash(pin, 10);
}

export async function verifyPin(pin: string, pinHash: string): Promise<boolean> {
  return bcrypt.compare(pin, pinHash);
}

export function setPlayerCookie(playerId: string) {
  cookies().set(PLAYER_COOKIE, sign(playerId), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: ONE_MONTH,
  });
}

export function clearPlayerCookie() {
  cookies().delete(PLAYER_COOKIE);
}

export function currentPlayerId(): string | null {
  return verify(cookies().get(PLAYER_COOKIE)?.value);
}

export async function currentPlayer() {
  const id = currentPlayerId();
  if (!id) return null;
  try {
    return await prisma.player.findUnique({ where: { id } });
  } catch {
    // DB unreachable or lookup failed — treat as logged out rather than crashing
    // the whole page with a server-side exception.
    return null;
  }
}
