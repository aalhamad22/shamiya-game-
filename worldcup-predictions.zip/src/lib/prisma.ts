// A single shared PrismaClient instance. In dev, Next.js hot-reload would
// otherwise create a new client on every reload and exhaust DB connections, so
// we cache it on globalThis.
import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

// Where is the database? Support both setups:
//  - DATABASE_URL          → if you brought your own Postgres (Neon/Supabase/local)
//  - NETLIFY_DATABASE_URL  → automatically set when you add a Netlify database
// We prefer your own DATABASE_URL if present, otherwise fall back to Netlify's.
const databaseUrl = process.env.DATABASE_URL || process.env.NETLIFY_DATABASE_URL;

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    // Only override the schema's datasource when we actually found a URL — if
    // neither var is set, let Prisma surface its normal error (caught upstream).
    ...(databaseUrl ? { datasourceUrl: databaseUrl } : {}),
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
