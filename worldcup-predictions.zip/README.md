# ⚽ World Cup 2026 Predictions

A small mobile-first web app where your friends predict the outcomes of the 2026
FIFA World Cup knockout matches (Round of 32 → Final). Everyone submits picks
under their name, and a shared public leaderboard ranks everyone by points. You
(the admin) enter results, manage fixtures, and fix mistakes from a password-
protected admin area.

All data lives in a **real shared Postgres database**, so 30 people on 30
different phones see the same fixtures and the same leaderboard.

- **Stack:** Next.js (App Router) + TypeScript · PostgreSQL via Prisma ·
  Tailwind CSS · deploys to Netlify free tier.
- **Times:** stored in UTC, always shown in **Kuwait time (UTC+3)**.

---

## Table of contents

1. [How scoring works](#how-scoring-works)
2. [What you need before you start](#what-you-need-before-you-start)
3. [Step 1 — Create the database (Neon)](#step-1--create-the-database-neon)
4. [Step 2 — Run it on your computer](#step-2--run-it-on-your-computer)
5. [Environment variables](#environment-variables)
6. [Step 3 — Deploy to Netlify](#step-3--deploy-to-netlify)
7. [Using the admin area](#using-the-admin-area)
8. [⚠️ Kickoff times you must verify](#️-kickoff-times-you-must-verify)
9. [Changing the scoring rules later](#changing-the-scoring-rules-later)
10. [Troubleshooting](#troubleshooting)

---

## How scoring works

For every match a player predicts **two things**: the **winner** and the
**method** (won in 90 minutes / extra time / penalties).

| Outcome | Points |
| --- | --- |
| Correct winner | **+2** |
| Correct method | **+1** |

By default the **+1 method point only counts if the winner was also correct**,
so each knockout match is worth **3, 2, or 0** points. This is controlled by a
single setting, `methodRequiresCorrectWinner` (default **on**). Turn it **off**
in the admin Settings tab to award the +1 whenever the method matches, even if
the winner was wrong (then matches can score 3 / 2 / 1 / 0).

**Group games** (any match where you untick the "Knockout" box): a draw is
allowed, the method is ignored, and a correct result is worth **+2**.

**Champion bonus** (on by default): each player also picks who wins the whole
tournament. If they're right they get a bonus (default **+5**,
`championBonusPoints`). This pick **locks** at a deadline you set (default: the
kickoff of the first Round of 32 match).

> A player's total = match points + champion bonus + any manual adjustments.
> The leaderboard is recalculated live every time you save a result, so there's
> nothing to "recompute" by hand.

The scoring code lives in [`src/lib/scoring.ts`](src/lib/scoring.ts) and is
heavily commented — it's the one file to edit if you want to change the rules.

---

## What you need before you start

1. **Node.js 18.18 or newer** (20 LTS recommended). Check with:
   ```bash
   node --version
   ```
   If you don't have it, install from <https://nodejs.org> (the "LTS" button).
2. A **GitHub account** (free) — to deploy to Netlify.
3. A **Netlify account** (free) — <https://netlify.com>.
4. A **Neon account** (free Postgres) — <https://neon.tech>.

You'll be copying/pasting a few values. Take your time; nothing here is risky.

---

## Step 1 — Create the database (Neon)

You only need ONE free database. (Supabase works too — see the note at the end
of this step.)

1. Go to <https://neon.tech> and sign up (you can use "Continue with GitHub").
2. Click **Create project**. Give it any name (e.g. `worldcup`). Pick the region
   closest to you. Click **Create**.
3. On the project dashboard you'll see a **Connection string**. Click to reveal
   and **copy it**. It looks like:
   ```
   postgresql://neondb_owner:abcd1234@ep-cool-name-12345.eu-central-1.aws.neon.tech/neondb?sslmode=require
   ```
   Keep this tab open — you'll paste this string in two places (locally and on
   Netlify). This is your **`DATABASE_URL`**.
4. For **`DIRECT_URL`**: Neon's connection string sometimes contains `-pooler`
   in the host. The simplest, always-works option is to use the **same string**
   for both `DATABASE_URL` and `DIRECT_URL`. (Advanced: use the non-pooled host —
   the one without `-pooler` — for `DIRECT_URL`.)

> **Using Supabase instead?** Create a project, then go
> **Project Settings → Database → Connection string → URI**. Use the
> **"Direct connection"** URI (port 5432) for both `DATABASE_URL` and
> `DIRECT_URL`. Everything else is identical.

---

## Step 2 — Run it on your computer

Open a terminal **in this project folder** and run these in order.

1. **Install the packages:**
   ```bash
   npm install
   ```

2. **Create your settings file.** Copy the example and open `.env` in a text
   editor:
   ```bash
   cp .env.example .env
   ```
   Fill in the four values (see [Environment variables](#environment-variables)
   below). At minimum paste your Neon string into `DATABASE_URL` **and**
   `DIRECT_URL`, choose an `ADMIN_PASSWORD`, and generate a `SESSION_SECRET`:
   ```bash
   # prints a random secret — paste the output as SESSION_SECRET
   openssl rand -hex 32
   ```

3. **Create the tables in your database:**
   ```bash
   npx prisma db push
   ```
   This reads `prisma/schema.prisma` and creates all the tables in your Neon
   database. You should see "Your database is now in sync with your Prisma
   schema."

4. **Load the Round of 32 fixtures + default settings:**
   ```bash
   npm run seed
   ```
   This adds the 16 Round-of-32 matches and the settings row. ⚠️ The **kickoff
   times are placeholders** — see
   [the list to verify](#️-kickoff-times-you-must-verify).

5. **Start the app:**
   ```bash
   npm run dev
   ```
   Open <http://localhost:3000>. You should see the homepage with the leaderboard
   (empty at first) and the upcoming matches. Admin is at
   <http://localhost:3000/admin>.

> Want to double-check the scoring/time logic? Run `npm test` — it runs a small
> set of checks (no database needed).

---

## Environment variables

These go in `.env` for local development, and into Netlify's site settings for
production. **The same four variables, the same values.**

| Variable | What it is | Example / how to get it |
| --- | --- | --- |
| `DATABASE_URL` | Your Postgres connection string. | Copied from Neon/Supabase. |
| `DIRECT_URL` | Connection string used for migrations. | Use the **same value** as `DATABASE_URL` if unsure. |
| `ADMIN_PASSWORD` | The single password for the admin area (just you). | Pick a long one, e.g. `correct-horse-battery-staple-2026`. |
| `SESSION_SECRET` | Random secret that signs login cookies. | Run `openssl rand -hex 32` and paste the output. |

**To set the admin password:** it's simply the `ADMIN_PASSWORD` value. Change it
any time by updating the variable (locally in `.env`, or on Netlify in
**Site configuration → Environment variables**, then redeploy). There's no
separate step.

---

## Step 3 — Deploy to Netlify

You'll put the code on GitHub, then connect it to Netlify. Netlify automatically
installs its **Next.js runtime**, so App Router pages, Server Actions, and the
API route all work with no extra setup. The included `netlify.toml` already sets
the build command and Node version for you.

### 3a. Put the code on GitHub

1. Create a new **empty** repository on GitHub (no README, it's already here).
2. In this project folder:
   ```bash
   git init
   git add .
   git commit -m "World Cup predictions app"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```
   (`.env` is git-ignored, so your secrets are **not** uploaded — good.)

### 3b. Import into Netlify

1. Go to <https://app.netlify.com>, click **Add new site → Import an existing
   project**, choose **GitHub**, authorise it, and pick the repo you just pushed.
2. Netlify reads `netlify.toml`, so the build command (`npm run build`) and
   publish settings are filled in automatically. **Leave them as-is.**
3. **Before clicking Deploy**, open **Add environment variables** (or do it right
   after, under **Site configuration → Environment variables**) and add all four:
   - `DATABASE_URL`
   - `DIRECT_URL`
   - `ADMIN_PASSWORD`
   - `SESSION_SECRET`

   (Paste the same values you used locally.)
4. Click **Deploy site**. Wait ~1–2 minutes. If you added the variables *after*
   the first build, click **Deploys → Trigger deploy → Deploy site** once so the
   build picks them up.

### 3c. One-time database setup

You already ran `npx prisma db push` and `npm run seed` in Step 2 against the
**same** Neon database Netlify is using, so your tables and fixtures are already
there — **nothing else to do**. Your live site is ready.

> If you skipped Step 2 (e.g. you set up the database only now), just run these
> two commands locally once, pointing at the same `DATABASE_URL`:
> ```bash
> npx prisma db push
> npm run seed
> ```

Your app is now live at `https://your-site-name.netlify.app` (you can rename it
under **Site configuration → Change site name**). Share that link with your
friends. Visit `/admin` and log in with your `ADMIN_PASSWORD`.

---

## Using the admin area

Go to `/admin` and enter your `ADMIN_PASSWORD`. You get three tabs:

- **⚽ Fixtures & Results**
  - **Add a match** — round, the two teams, kickoff in **Kuwait time**, and a
    "Knockout" tick (untick it for a group game where a draw is allowed). Adding
    is quick — use it as the bracket fills in (Round of 16 onward).
  - **Enter result** — pick the winner and the method on any match. Saving
    instantly updates everyone's leaderboard.
  - **Edit / Delete** any fixture, and **View predictions** to see what everyone
    picked for a match.
- **✏️ Adjustments** — add or subtract points for a player with a short reason
  (the "fix a mistake" tool). Every change is kept in an audit log you can see
  and undo.
- **⚙️ Settings** — edit `methodRequiresCorrectWinner`, the champion bonus
  points, the champion deadline, the tournament name, and **set the champion
  result** (which team won the cup) to trigger the champion bonus.

Players never see any of this — they just use the home page, **Play**, and
**My picks**.

---

## ⚠️ Kickoff times you must verify

The Round of 32 **matchups** below are correct, but the **kickoff dates/times
are placeholders** that the seed put in. Open the Admin → Fixtures tab and fix
any that don't match the official FIFA schedule. (All times are **Kuwait
time**.)

| Match | Placeholder kickoff (Kuwait) | Verify? |
| --- | --- | --- |
| South Africa vs Canada | Sun 28 Jun, 19:00 | ✅ verify time |
| Brazil vs Japan | Sun 28 Jun, 23:00 | ✅ verify time |
| Germany vs Paraguay | Mon 29 Jun, 19:00 | ✅ verify time |
| Netherlands vs Morocco | Mon 29 Jun, 23:00 | ✅ verify time |
| Ivory Coast vs Norway | Tue 30 Jun, 19:00 | ✅ verify time |
| France vs Sweden | Tue 30 Jun, 23:00 | ✅ verify time |
| Mexico vs Ecuador | Wed 1 Jul, 19:00 | ✅ verify time |
| England vs DR Congo | Wed 1 Jul, 23:00 | ✅ verify time |
| Belgium vs Senegal | Thu 2 Jul, 19:00 | ✅ verify time |
| United States vs Bosnia and Herzegovina | Thu 2 Jul, 23:00 | ✅ verify time |
| Spain vs Austria | Fri 3 Jul, 19:00 | ✅ verify time |
| Switzerland vs Algeria | Fri 3 Jul, 23:00 | ✅ verify time |
| Portugal vs Croatia | Sat 4 Jul, 19:00 | ✅ verify time |
| Australia vs Egypt | Sat 4 Jul, 23:00 | ✅ verify time |
| Argentina vs Cabo Verde | Sun 5 Jul, 19:00 | ✅ verify time |
| **Colombia vs TBD** | Sun 5 Jul, 23:00 | ⚠️ **opponent AND time** — set the real opponent in Admin |

Because the champion-pick deadline defaults to the **first** match's kickoff,
update that deadline in **Settings** too once you've confirmed the real first
kickoff (or just set whatever deadline you prefer).

Adding teams later? Team flags/3-letter codes are defined in
[`src/lib/teams.ts`](src/lib/teams.ts). Unknown teams still work (they get a
generic flag and the first 3 letters) — add them to that file for nicer display.

---

## Changing the scoring rules later

- **Point values** (the +2 / +1): edit the `WINNER_POINTS` / `METHOD_POINTS`
  constants and the `scoreMatch` function in
  [`src/lib/scoring.ts`](src/lib/scoring.ts). It's commented step by step.
- **Method-requires-winner toggle** and **champion bonus**: no code needed —
  change them in the admin **Settings** tab.

---

## Troubleshooting

- **"Environment variable not found: DIRECT_URL"** — set `DIRECT_URL` in `.env`
  (and on Netlify). If you only have one connection string, set it to the same
  value as `DATABASE_URL`.
- **`prisma db push` can't connect** — double-check the connection string is
  pasted exactly (including `?sslmode=require`) and that your Neon project is
  active (free Neon projects can sleep; opening the Neon dashboard wakes it).
- **Leaderboard didn't update after I entered a result** — it auto-refreshes
  about every 45 seconds; give it a moment or reload.
- **A player forgot their PIN** — there's no self-service reset (by design, to
  keep it simple). You can delete that player row in the Neon dashboard's table
  editor and they can re-register the name, or just create a slightly different
  name.
- **Security note:** `npm audit` may report advisories in Next.js. This project
  pins the latest Next.js 14 LTS patch (`14.2.33`). For a private game shared
  with friends this is fine; if you want, you can later upgrade to Next 15/16.

---

Enjoy the tournament! 🏆
